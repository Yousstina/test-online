<?php
    $services = \App\Service::where('active','active')->get();
?>

<div class="service-section home-3" id="services">
         <div class="container">
            <span class="title"><?php echo app('translator')->getFromJson('home.our_services'); ?></span>
            <h2 class="subtitle"><?php echo app('translator')->getFromJson('home.what_we_provide'); ?></h2>
            <div class="services">
               <div class="row">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-lg-4 col-md-6">
                     <div class="single-service wow fadeInUp" data-wow-duration="1.5s">
                        <div class="icon-wrapper"><i class="flaticon-<?php echo e($service->icon); ?>"></i></div>
                        <div class="service-txt">
                           <h4 class="service-title"><?php echo e(Unserialize($service['head'])[LaravelLocalization::getCurrentLocale()]); ?></h4>
                           <p class="service-para"><?php echo e(Unserialize($service['body'])[LaravelLocalization::getCurrentLocale()]); ?></p>
                        </div>
                     </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
         </div>
      </div>