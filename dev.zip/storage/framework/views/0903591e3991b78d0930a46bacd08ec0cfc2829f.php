<?php
    $blogs = \App\Blog::where('active','active')->get();
?>

<div class="news-section" id="news">
         <div class="container">
            <span class="title"><?php echo app('translator')->getFromJson('home.latest_news'); ?></span>
            <h2 class="subtitle"><?php echo app('translator')->getFromJson('home.inside_the_news'); ?></h2>
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="col-lg-4 col-md-6">
                      <div class="single-news wow fadeInRight" data-wow-duration="1.5s">
                         <img src="<?php echo e(asset('/manage/img/blogs/'.$blog['image'])); ?>" alt="">
                         <div class="news-txt">
                            <span class="date"><?php echo e(date("d", strtotime($blog->created_at))); ?> <?php echo e(date("M", strtotime($blog->created_at))); ?>  -  BY <?php echo e(Unserialize($blog['author'])[LaravelLocalization::getCurrentLocale()]); ?></span>
                            <a href="<?php echo e(route('singleBlog',$blog->id)); ?>" class="title">
                               <h3><?php echo e(Unserialize($blog['head'])[LaravelLocalization::getCurrentLocale()]); ?></h3>
                            </a>
                            <a class="readmore" href="<?php echo e(route('singleBlog',$blog->id)); ?>">Read More</a>
                         </div>
                      </div>
                   </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
      </div>