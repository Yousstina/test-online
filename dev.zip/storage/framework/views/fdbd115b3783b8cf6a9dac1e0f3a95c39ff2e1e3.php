 

<?php $__env->startSection('content'); ?>
<style type="text/css">
    .bb{
        padding: 6px 19px;
        font-size: 14px;
        line-height: 24px;
        font-weight: bold;
        background: #60a7d4; 
        display: table;
        color: #fff;
        cursor: pointer;
        text-align: center;
        border-radius: 8px;
        border-width: 2px;
         }



    input[type="file"] {
        display: none;
    }

    input[type="file"] {
        display: none;
    }
</style> 
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">      
                    <div class="col-lg-12">
                        <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="card">
                            <div class="card-header">
                                <strong>Testimonial</strong>
                                <small> add</small>
                            </div>
                            <div class="card-body card-block">
                                <form action="<?php echo e(route('admin.testimonials.store')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-6">

                                                <div class="form-group">
                                                    <label class="control-label mb-1">Body in <?php echo e($value['native']); ?></label>
                                                    <textarea name="body[<?php echo e($key); ?>]" type="text" class="form-control"  placeholder="<?php echo e($value['native']); ?>" required></textarea>
                                                </div>

                                                <div class="form-group">
                                                    <label class="control-label mb-1">User name in <?php echo e($value['native']); ?></label>
                                                    <input name="user_name[<?php echo e($key); ?>]" type="text" class="form-control"  placeholder="<?php echo e($value['native']); ?>" required>
                                                </div>

                                                <div class="form-group">
                                                    <label class="control-label mb-1">Job Title in <?php echo e($value['native']); ?></label>
                                                    <input name="job_title[<?php echo e($key); ?>]" type="text" class="form-control"  placeholder="<?php echo e($value['native']); ?>" required>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="form-group">
                                      <label class="bb"> add image
                                            <input type="file" name="image" multiple required>
                                      </label>
                                    </div>
                                    <div class="clearfix"></div>

                                    <div class="row">
                                        <div class="col-8">
                                            <div>
                                                <button type="submit" name="submit" class="btn btn-lg btn-success btn-block">
                                                    <i class="fa fa-plus fa-lg"></i>&nbsp;
                                                    <span>add</span>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div>
                                                <a href="<?php echo e(route('admin.testimonials.index')); ?>" type="submit" name="cancel" class="btn btn-lg btn-danger btn-block">
                                                    <i class="fa fa-mail-forward fa-lg"></i>&nbsp;
                                                    <span>Back</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>