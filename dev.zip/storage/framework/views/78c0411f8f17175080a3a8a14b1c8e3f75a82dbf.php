 

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row">
                
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <h3 class="title-5 m-b-35">All Home Abouts</h3>
                    <div class="table-data__tool">
                        
                        <div class="table-data__tool-right">
                            <a href="<?php echo e(route('admin.home_about.create')); ?>" class="au-btn au-btn-icon au-btn--green au-btn--small">
                                <i class="zmdi zmdi-plus"></i>add home about
                            </a>

                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-md btn-danger">
                                <i class="fa fa-mail-forward"></i> back
                            </a>
                            
                        </div>
                    </div>
                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>head</th>
                                    <th>العنوان</th>
                                    <th>Image</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $home_abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr class="tr-shadow">
                                    <td><?php echo e($ha->id); ?></td>
                                    <td><?php echo e(Unserialize($ha->head)[LaravelLocalization::setLocale('en')]); ?></td>
                                    <td><?php echo e(Unserialize($ha->head)[LaravelLocalization::setLocale('ar')]); ?></td>

                                    <td>
                                        <img style="width: 180px; height: 70px; border-radius: 2%;" src="<?php echo e(asset('/manage/img/home_abouts/'.$ha->image)); ?>" alt="">
                                    </td>
                            
                                    <td>
                                        <?php if($ha->active == 'inactive'): ?>
                                        <a href="<?php echo e(route('admin.home_about.changeStatus',$ha->id)); ?>" class="btn btn-md btn-danger">
                                            Inactive
                                        </a>
                                        <?php elseif($ha->active == 'active'): ?>
                                        <a href="<?php echo e(route('admin.home_about.changeStatus',$ha->id)); ?>" class="btn btn-md btn-success">
                                            active
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="table-data-feature">
                                            <a href="<?php echo e(route('admin.home_about.edit',$ha->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                <i class="zmdi zmdi-edit"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.home_about.delete',$ha->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                <i class="zmdi zmdi-delete"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                            <?php echo e($home_abouts->links()); ?>

                        </table>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>