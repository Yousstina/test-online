
<!-- MENU SIDEBAR-->
<aside class="menu-sidebar2">
    <div class="logo">
        <a href="<?php echo e(route('admin.home')); ?>">
            <img src="<?php echo e(asset('manage/images/icon/logo-white.png')); ?>" alt="kayan" />
        </a>
    </div>
    <div class="menu-sidebar2__content js-scrollbar1">
        <nav class="navbar-sidebar2">
            <ul class="list-unstyled navbar__list">
                <li class="active">
                    <a href="<?php echo e(route('admin.home')); ?>">
                        <i class="fas fa-tachometer-alt"></i>Home
                    </a>                
                </li>

                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-users"></i>Users
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.users.index')); ?>">
                                <i class="fas fa-th-list"></i>show all users</a>
                        </li>
                    </ul>
                </li>
                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-edit"></i>Exam Types
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.exams.index')); ?>">
                                <i class="fas fa-th-list"></i>show all types</a>
                        </li>

                        <li>
                            <a href="<?php echo e(route('admin.exams.index')); ?>">
                                <i class="fas fa-plus"></i>add type</a>
                        </li>
                    </ul>
                </li>
                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-tags"></i>Positions
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.positions.index')); ?>">
                                <i class="fas fa-th-list"></i>show all positions</a>
                        </li>

                        <li>
                            <a href="<?php echo e(route('admin.positions.index')); ?>">
                                <i class="fas fa-plus"></i>add position</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<!-- END MENU SIDEBAR-->