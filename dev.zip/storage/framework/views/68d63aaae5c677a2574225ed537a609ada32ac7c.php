 

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row">
                
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <h3 class="title-5 m-b-35">All Sliders</h3>
                    <div class="table-data__tool">
                        
                        <div class="table-data__tool-right">
                            <a href="<?php echo e(route('admin.sliders.create')); ?>" class="au-btn au-btn-icon au-btn--green au-btn--small">
                                <i class="zmdi zmdi-plus"></i>add slider
                            </a>

                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-md btn-danger">
                                <i class="fa fa-mail-forward"></i> back
                            </a>
                            
                        </div>
                    </div>
                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>head</th>
                                    <th>video link</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr class="tr-shadow">
                                    <td><?php echo e($slider->id); ?></td>

                                    
                                    <td>
                                        <?php echo e(Unserialize($slider->head)[LaravelLocalization::setLocale('en')]); ?>

                                    </td>

                                    <td>
                                        <a href="<?php echo e($slider->video_link); ?>"><?php echo e($slider->video_link); ?></a>
                                    </td>
                                    
                                    <td>
                                        <?php if($slider->active == 'inactive'): ?>
                                        <a href="<?php echo e(route('admin.sliders.changeStatus',$slider->id)); ?>" class="btn btn-md btn-danger">
                                            Inactive
                                        </a>
                                        <?php elseif($slider->active == 'active'): ?>
                                        <a href="<?php echo e(route('admin.sliders.changeStatus',$slider->id)); ?>" class="btn btn-md btn-success">
                                            active
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="table-data-feature">
                                            <a href="<?php echo e(route('admin.sliders.edit',$slider->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                <i class="zmdi zmdi-edit"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.sliders.delete',$slider->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                <i class="zmdi zmdi-delete"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                            <?php echo e($sliders->links()); ?>

                        </table>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>