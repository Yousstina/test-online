<?php
    $logo = \App\Logo::where('active','active')->orderBy('id','desc')->first();
    $socials = \App\Social::where('active','active')->get();
    $brands = \App\Brand::where('active','active')->get();
    $info = \App\Info::where('active','active')->orderBy('id','desc')->first();
?>

<!--   header area start   -->
  <div class="header-area">
     <div class="info-bar">
        <div class="container">
           <div class="row">
              <div class="col-lg-4 col-8">
                 <ul class="social-links">
                    <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($social->link); ?>"><i class="fab fa-<?php echo e($social->lowercase); ?>"></i></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </ul>
              </div>
              <div class="col-lg-8 col-4">
                 <div class="right-content">
                    <div class="language">
                       <a href="#" class="dropdown-btn"><?php echo app('translator')->getFromJson('home.language'); ?> <i class="flaticon-down-arrow"></i></a>
                       <ul class="language-dropdown">
                          <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                               <a href="<?php echo e(LaravelLocalization::getLocalizedUrl($key)); ?>"><?php echo e($value['native']); ?></a>
                            </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </ul>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </div>
     <div class="support-nav-area">
        <div class="container">
           <div class="row">
              <div class="col-lg-3 col-6">
                 <div class="logo-wrapper">
                    <div class="logo-wrapper-inner">
                       <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/manage/img/logos/'.$logo['image'])); ?>" alt=""></a>
                    </div>
                 </div>
              </div>
              <div class="col-lg-9 col-6 position-lg-relative position-static">
                 <div class="support-bar">
                    <div class="row">
                       <div class="offset-xl-4 col-xl-8 offset-2 col-10">
                          <div class="row">
                             <div class="col-lg-6">
                                <div class="support-info">
                                   <div class="left-content"><i class="flaticon-call"></i></div>
                                   <div class="right-content">
                                      <div class="right-content-inner">
                                         <h5>Free Call</h5>
                                         <p><?php echo e($info['phone']); ?></p>
                                      </div>
                                   </div>
                                </div>
                             </div>
                             <div class="col-lg-6">
                                <div class="support-info">
                                   <div class="left-content"><i class="flaticon-email"></i></div>
                                   <div class="right-content">
                                      <h5>Mail us</h5>
                                      <p><?php echo e($info['email']); ?> </p>
                                   </div>
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
                 <div class="navbar-area">
                    <div class="row">
                       <div class="col-lg-12 d-lg-block d-none">
                          <nav class="main-menu" id="mainMenu">
                             <ul>
                                <li class="active">
                                   <a href="<?php echo e(url('/')); ?>#html"><?php echo app('translator')->getFromJson('home.home'); ?></a>
                                </li>

                                <li class="dropdown">
                                   <a href="<?php echo e(url('/')); ?>#brands"><?php echo app('translator')->getFromJson('home.brands'); ?></a>
                                   <ul>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <li><a target="_blank" href="<?php echo e($brand->link); ?>"><?php echo e(Unserialize($brand['name'])[LaravelLocalization::getCurrentLocale()]); ?></a></li>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </ul>
                                </li>

                                <li>
                                   <a href="<?php echo e(url('/')); ?>#ours"><?php echo app('translator')->getFromJson('home.our_mission'); ?></a>
                                </li>
                                <li>
                                   <a href="<?php echo e(url('/')); ?>#about"><?php echo app('translator')->getFromJson('home.about_us'); ?></a>
                                </li>
                                <li>
                                   <a href="<?php echo e(url('/')); ?>#services"><?php echo app('translator')->getFromJson('home.services'); ?></a>
                                </li>
                                <li>
                                   <a href="<?php echo e(url('/')); ?>#news"><?php echo app('translator')->getFromJson('home.latest_news'); ?></a>
                                </li>
                                <li>
                                   <a href="<?php echo e(url('/')); ?>#testimonials"><?php echo app('translator')->getFromJson('home.testimonials'); ?></a>
                                </li>
                             </ul>
                          </nav>
                       </div>
                       <div class="col-lg-3 col-12 position-lg-relative position-static">
                          <div id="mobileMenu"></div>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </div>
  </div>
  <!--   header area end   -->

  