<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<title><?php echo $__env->yieldContent('title'); ?></title>
<?php echo $__env->make('front-end._includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

   <body>

      <?php echo $__env->yieldContent('content'); ?>
      
      
      
      <!--   footer section start    -->
      <?php echo $__env->make('front-end._includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--   footer section end    -->
      
      
      <!-- preloader section start -->
    
      <!-- preloader section end -->
      
      
      <!-- back to top area start -->
      <div class="back-to-top">
         <i class="fas fa-chevron-up"></i>
      </div>
      <!-- back to top area end -->   
      
       
         
      <!-- popper js -->
      <script src="<?php echo e(asset('front/assets/js/popper.min.js')); ?>"></script>
      <!-- bootstrap js -->
      <script src="<?php echo e(asset('front/assets/js/bootstrap.min.js')); ?>"></script>
      <!-- owl carousel js -->
      <script src="<?php echo e(asset('front/assets/js/owl.carousel.min.js')); ?>"></script>
      <!-- isotope js -->
      <script src="<?php echo e(asset('front/assets/js/isotope.pkgd.min.js')); ?>"></script>
      <!-- slicknav js -->
      <script src="<?php echo e(asset('front/assets/js/jquery.slicknav.min.js')); ?>"></script>
      <!-- wow js -->
      <script src="<?php echo e(asset('front/assets/js/wow.min.js')); ?>"></script>
      <!-- video background js -->
      <script src="<?php echo e(asset('front/assets/js/YTPlayer.min.js')); ?>"></script>
      <!-- main js -->
      <script src="<?php echo e(asset('front/assets/js/main.js')); ?>"></script>
   </body>

</html>