<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">

    <!-- Title Page-->
    <title>Add Question</title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('manage/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('manage/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.css">
    <!-- Vendor CSS-->
    <link href="<?php echo e(asset('manage/vendor/animsition/animsition.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/wow/animate.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/css-hamburgers/hamburgers.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/slick/slick.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/select2/select2.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/perfect-scrollbar/perfect-scrollbar.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/vector-map/jqvmap.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="<?php echo e(asset('manage/css/theme.css')); ?>" rel="stylesheet" media="all">

</head>

<body >
    <div class="page-wrapper">
        <?php echo $__env->make('multiauth::_includes.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <?php echo $__env->make('multiauth::_includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- PAGE CONTAINER-->
    <div>
        <!-- MAIN CONTENT-->
        <div class="main-content">
            <div class="section__content section__content--p30">
                <div class="container-fluid">
                     <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">questions</div>
                                <div class="card-body">
                                    <div class="card-title">
                                        <h3 class="text-center title-2">Add New Question</h3>
                                    </div>
                                    <hr>
                                    <form action="<?php echo e(route('admin.questions.store',$exam_id)); ?>" method="post" novalidate="novalidate" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group">
                                            <label class="control-label mb-1">Question in <?php echo e($value['native']); ?></label>
                                            <textarea class="form-control" name="head[<?php echo e($key); ?>]" placeholder="<?php echo e($value['native']); ?>"></textarea>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group">
                                      
                                          <div class="field_wrapper">
                                              <div>
                                                  <input type="text" name="char[]" id="char" placeholder="char" style="width: 90px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;" class="form-control" required/>

                                                  <input type="text" name="answer_en[]" id="answer_en" placeholder="answer in english" style="width: 300px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;" class="form-control" required/>

                                                  <input type="text" name="answer_ar[]" id="answer_ar" placeholder="answer in arabic" style="width: 300px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;" class="form-control" required/>

                                                   <select name="status[]" class="form-control" style="width: 110px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;">
                                                        <option value="1">correct</option>
                                                        <option value="0">not correct</option>
                                                   </select>
                                                  <a href="javascript:void(0);" class="add_button" title="Add field">Add</a>
                                              </div>
                                          </div>
                                        </div> 
                                        <div>
                                            <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                <span id="payment-button-amount">add question</span>
                                                <span id="payment-button-sending" style="display:none;">adding…</span>
                                            </button>

                                            <a style="color: #fff;" class="btn btn-lg btn-danger btn-block" href="<?php echo e(route('admin.questions.index',$exam_id)); ?>">
                                                <span id="payment-button-amount">Back</span>
                                            </a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END MAIN CONTENT-->

        <!-- END PAGE CONTAINER-->
    </div>
    <!-- Add Remove fields JQUERY Dynamically -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
          var maxField = 10; //Input fields increment limitation
          var addButton = $('.add_button'); //Add button selector
          var wrapper = $('.field_wrapper'); //Input field wrapper
          var fieldHTML = '<div class="field_wrapper"><input type="text" name="char[]" id="char" placeholder="char" style="width: 90px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;" class="form-control"/> <input type="text" name="answer_en[]" id="answer_en" placeholder="answer in english" style="width: 300px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;" class="form-control" required/> <input type="text" name="answer_ar[]" id="answer_ar" placeholder="answer in arabic" style="width: 300px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;" class="form-control" required/> <select name="status[]" class="form-control" style="width: 110px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;"> <option value="1">correct</option><option value="0">not correct</option> </select>  <a href="javascript:void(0);" class="remove_button">Remove</a></div></div>'; //New input field html 
          var x = 1; //Initial field counter is 1
          
          //Once add button is clicked
          $(addButton).click(function(){
              //Check maximum number of input fields
              if(x < maxField){ 
                  x++; //Increment field counter
                  $(wrapper).append(fieldHTML); //Add field html
              }
          });
          
          //Once remove button is clicked
          $(wrapper).on('click', '.remove_button', function(e){
              e.preventDefault();
              $(this).parent('div').remove(); //Remove field html
              x--; //Decrement field counter
          });
          });
     </script>

      <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
        });
    </script>
            <?php echo $__env->make('multiauth::_includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

     <!-- Jquery JS-->
    <script src="<?php echo e(asset('manage/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo e(asset('manage/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <!-- Vendor JS       -->
    <script src="<?php echo e(asset('manage/vendor/slick/slick.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/animsition/animsition.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/counter-up/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/counter-up/jquery.counterup.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/circle-progress/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/chartjs/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/select2/select2.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.sampledata.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.world.js')); ?>"></script>

    <!-- Main JS-->
    <script src="<?php echo e(asset('manage/js/main.js')); ?>"></script>

</body>

</html>
<!-- end document-->