 

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">      
                <div class="col-lg-12">
                    <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="card">
                        <div class="card-header">
                            <strong>Exam</strong>
                            <small> add to</small>
                            <strong> User</strong>
                        </div>
                        <div class="card-body card-block">
                            <form action="<?php echo e(route('admin.users.assign',$user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-8">
                                        <div class="form-group">
                                            <label class="control-label mb-1">Select Exam</label>
                                            <select name="exam_id" class="form-control" required>
                                                <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($exam->id); ?>"><?php echo e(Unserialize($exam->name)[LaravelLocalization::setLocale('en')]); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-8">
                                        <div>
                                            <button type="submit" name="submit" class="btn btn-lg btn-success btn-block">
                                                <i class="fa fa-plus fa-lg"></i>&nbsp;
                                                <span>add</span>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div>
                                            <a href="<?php echo e(route('admin.users.index')); ?>" type="submit" name="cancel" class="btn btn-lg btn-danger btn-block">
                                                <i class="fa fa-mail-forward fa-lg"></i>&nbsp;
                                                <span>Back</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <h3 class="title-5 m-b-35">All Exams for User <?php echo e($user->name); ?></h3>
                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>name</th>
                                    <th>Score</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr class="tr-shadow">
                                    <td><?php echo e($user_exam->id); ?></td>
                                    <?php
                                        $exam = \App\Exam::where('id',$user_exam->exam_id)->first();
                                    ?>
                                    <td><?php echo e(Unserialize($exam->name)[LaravelLocalization::setLocale('en')]); ?></td>
                                    <?php if($user_exam->score == null): ?>
                                    <td>No score yet</td>
                                    <?php else: ?>
                                    <td><?php echo e($user_exam->score); ?></td>
                                    <?php endif; ?>
                                    <td>
                                        <div class="table-data-feature">
                                            <a href="<?php echo e(route('admin.users.deleteExam',$user_exam->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                <i class="zmdi zmdi-delete"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>