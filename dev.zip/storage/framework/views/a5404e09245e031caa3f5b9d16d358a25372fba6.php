<!DOCTYPE html>
<?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
<html lang="en">
<?php elseif(LaravelLocalization::getCurrentLocale() == 'ar'): ?>
<html lang="ar" dir="rtl">
<?php endif; ?>
<title><?php echo $__env->yieldContent('title'); ?></title>
<?php echo $__env->make('front-end._includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body id="page-top">

  <?php echo $__env->yieldContent('content'); ?>
  
<!-- Bootstrap core JavaScript -->
  <script src="<?php echo e(asset('assets/front/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/front/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

  <!-- Plugin JavaScript -->
  <script src="<?php echo e(asset('assets/front/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

  <!-- Custom scripts for this template -->
  <script src="<?php echo e(asset('assets/front/js/resume.min.js')); ?>"></script>
</body>

</html>
