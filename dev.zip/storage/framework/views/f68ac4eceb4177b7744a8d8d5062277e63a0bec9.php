<?php
    $logo = \App\Logo::where('active','active')->orderBy('id','desc')->first();
    $info = \App\Info::where('active','active')->orderBy('id','desc')->first();
?>



<footer class="bg-dark footer_dark">
   <div class="top_footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-8 mb-4 mb-lg-0">
                  <div class="footer_logo">
                     <a href="#"><img alt="logo" src="<?php echo e(asset('manage/img/logos/'.$logo['image'])); ?>"></a>
                    </div>
                    <p>Phasellus blandit massa enim. elit id varius nunc. Lorem ipsum dolor sit amet, consectetur industry.</p>
                    <ul class="contact_info contact_info_light list_none">
                        <li>
                            <i class="fa fa-map-marker-alt "></i>
                            <address><?php echo e(Unserialize($info['address'])[LaravelLocalization::getCurrentLocale()]); ?></address>
                        </li>
                        <li>
                            <i class="fa fa-envelope"></i>
                            <a href="mailto:info@sitename.com"><?php echo e($info['email']); ?></a>
                        </li>
                        <li>
                            <i class="fa fa-mobile-alt"></i>
                            <p><?php echo e($info['phone']); ?></p>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-2 col-sm-4 mb-4 mb-lg-0">
                  <h6 class="widget_title"><?php echo app('translator')->getFromJson('home.links'); ?></h6>
                    <ul class="list_none widget_links links_style1">
                     <li><a href="#">Join Us</a></li>
                        <li><a href="#"><?php echo app('translator')->getFromJson('home.home'); ?></a></li>
                        <li><a href="#">Features</a></li>
                        <li><a href="#">Feedback</a></li>
                        <li><a href="#">Support center</a></li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                  <h6 class="widget_title">Recent Posts</h6>
                    <ul class="recent_post border_bottom_dash list_none">
                      <li>
                         <div class="post_footer">
                            <div class="post_img">
                               <a href="#"><img src="<?php echo e(asset('front/assets/images/letest_post2.jpg')); ?>" alt="letest_post1"></a>
                              </div>
                              <div class="post_content">
                               <h6><a href="#">Lorem ipsum dolor sit amet, consectetur</a></h6>
                                  <span class="post_date">April 14, 2018</span>
                              </div>
                          </div>
                      </li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-6">
                    <h6 class="widget_title">Subscribe Newsletter</h6>
                    <p>Contrary to popular belief of lorem Ipsm Latin amet ltin from consectetur industry.</p>
                    <div class="newsletter_form mb-4">
                        <form> 
                            <input type="text" class="form-control" required="" placeholder="Email Address">
                            <button type="submit" title="Subscribe" class="btn btn-default btn-sm" name="submit" value="Submit">Subscribe</button>
                        </form>
                    </div>
                    <h6 class="widget_title">Follow Us</h6>
                    <ul class="list_none social_icons radius_social social_white social_style1">
                     <li><a href="#"><i class="ion-social-facebook"></i></a></li>
                        <li><a href="#"><i class="ion-social-twitter"></i></a></li>
                        <li><a href="#"><i class="ion-social-googleplus"></i></a></li>
                        <li><a href="#"><i class="ion-social-youtube-outline"></i></a></li>
                        <li><a href="#"><i class="ion-social-instagram-outline"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom_footer bg_black">
      <div class="container">
         <div class="row align-items-center">
               <div class="col-md-6">
                  <p class="copyright m-md-0 text-center text-md-left">© <?php echo app('translator')->getFromJson('home.copyrights'); ?> FETC. <?php echo app('translator')->getFromJson('home.rights'); ?>.</p>
                </div>
                <div class="col-md-6">
                  <ul class="list_none footer_link text-center text-md-right">
                     <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms &amp; Conditions</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>


