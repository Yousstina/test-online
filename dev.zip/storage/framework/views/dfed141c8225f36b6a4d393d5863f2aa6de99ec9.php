<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>GTSS |Login</title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('manage/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('manage/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?php echo e(asset('manage/vendor/animsition/animsition.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/wow/animate.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/css-hamburgers/hamburgers.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/slick/slick.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/select2/select2.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/perfect-scrollbar/perfect-scrollbar.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/vector-map/jqvmap.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="<?php echo e(asset('manage/css/theme.css')); ?>" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <?php if($errors->count() > 0): ?>
        <div class="error-msg">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="errorMessage alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e($error); ?>

            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <img src="<?php echo e(asset('manage/images/icon/logo.png')); ?>" alt="kayan">
                            </a>
                        </div>
                        <div class="login-form">
                            <form method="POST" action="<?php echo e(route('admin.login')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="email">Email Address</label>
                                    <input id="email" class="au-input au-input--full<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" type="email" name="email" placeholder="Email" autofocus value="<?php echo e(old('email')); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input id="password" class="au-input au-input--full<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" type="password" name="password" placeholder="Password">
                                </div>
                                <div class="login-checkbox">
                                    <label for="remember">
                                        <input id="remember" type="checkbox" name="remember" <?php echo e(old( 'remember') ? 'checked' : ''); ?>>Remember Me
                                    </label>
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">sign in</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Jquery JS-->
    <script src="<?php echo e(asset('manage/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo e(asset('manage/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <!-- Vendor JS       -->
    <script src="<?php echo e(asset('manage/vendor/slick/slick.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/animsition/animsition.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/counter-up/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/counter-up/jquery.counterup.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/circle-progress/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/chartjs/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/select2/select2.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.sampledata.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.world.js')); ?>"></script>

    <!-- Main JS-->
    <script src="<?php echo e(asset('manage/js/main.js')); ?>"></script>
   

</body>

</html>
<!-- end document-->
