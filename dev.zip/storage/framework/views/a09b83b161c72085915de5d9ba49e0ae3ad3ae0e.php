<?php
    $courses = \App\Course::where('active','active')->orderBy('id','desc')->get();
?>

<section class="small_pt">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-xl-6 col-lg-8">
               <div class="text-center animation" data-animation="fadeInUp" data-animation-delay="0.01s">
                    <div class="heading_s1 text-center">
                        <h2>Our Courses</h2>
                    </div>
                    <p>If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text</p>
                </div>
            </div>
        </div>
        <div class="row">
          <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-lg-4 col-sm-6">
               <div class="content_box radius_all_10 box_shadow1 animation" data-animation="fadeInUp" data-animation-delay="0.02s">
                  <div class="content_img radius_ltrt_10">
                     <a href="<?php echo e(route('singleCourse',$course->id)); ?>"><img src="<?php echo e(asset('manage/img/courses/'.$course['image'])); ?>" alt="course_img1"/></a>
                    </div>
                    <div class="content_desc">
                     <h4 class="content_title"><a href="<?php echo e(route('singleCourse',$course->id)); ?>"><?php echo e(Unserialize($course['head'])[LaravelLocalization::getCurrentLocale()]); ?></a></h4>
                        <p><?php echo substr(strip_tags(Unserialize($course->body)[LaravelLocalization::getCurrentLocale()]), 0, 120); ?>...</p>
                        <div class="courses_info">
                           <div class="rating_stars">
                              <?php for($i=1; $i<=$course['rate'];$i++): ?>
                                <i class="ion-android-star"></i>
                              <?php endfor; ?>
                            </div>
                            <ul class="list_none content_meta">
                                <li><a href="<?php echo e(route('singleCourse',$course->id)); ?>" ><i class="ti-user"></i>31</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="content_footer">
                        <div class="teacher">
                            <a href="<?php echo e(route('singleCourse',$course->id)); ?>"><span><?php echo e(Unserialize($course['instrutor'])[LaravelLocalization::getCurrentLocale()]); ?></span></a>
                        </div>
                        <div class="price">
                           <span class="alert alert-success"><?php echo e($course->price); ?> SAR</span>
                        </div>
                    </div>
                </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
         <div class="col-12">
               <div class="text-center animation" data-animation="fadeInUp" data-animation-delay="0.07s">
                  <div class="medium_divider"></div>
                  <a href="#" class="btn btn-default">View All Courses <i class="ion-ios-arrow-thin-right ml-1"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="parallax_bg overlay_bg_blue_70" data-parallax-bg-image="<?php echo e(asset('front/assets/images/counter_bg.jpg')); ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-6 ">
                <div class="box_counter counter_style1 text_white text-center animation" data-animation="fadeInUp" data-animation-delay="0.02s">
                  <div class="counter_icon">
                     <img src="<?php echo e(asset('front/assets/images/counter_icon1.png')); ?>" alt="counter_icon1" />
                    </div>
                    <div class="counter_content">
                        <h3 class="counter_text"><span class="counter">1800</span>+</h3>
                        <p>Students</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-6 ">
                <div class="box_counter counter_style1 text_white text-center animation" data-animation="fadeInUp" data-animation-delay="0.03s">
                    <div class="counter_icon">
                     <img src="<?php echo e(asset('front/assets/images/counter_icon2.png')); ?>" alt="counter_icon2" />
                    </div>
                    <div class="counter_content">
                        <h3 class="counter_text"><span class="counter">70</span></h3>
                        <p>Courses</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-6 ">
                <div class="box_counter counter_style1 text_white text-center animation" data-animation="fadeInUp" data-animation-delay="0.04s">
                    <div class="counter_icon">
                     <img src="<?php echo e(asset('front/assets/images/counter_icon3.png')); ?>" alt="counter_icon3" />
                    </div>
                    <div class="counter_content">
                        <h3 class="counter_text"><span class="counter">700</span>+</h3>
                        <p>Certified teachers</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-6 ">
                <div class="box_counter counter_style1 text_white text-center animation" data-animation="fadeInUp" data-animation-delay="0.05s">
                  <div class="counter_icon">
                     <img src="<?php echo e(asset('front/assets/images/counter_icon4.png')); ?>" alt="counter_icon4" />
                    </div>
                    <div class="counter_content">
                        <h3 class="counter_text"><span class="counter">1200</span>+</h3>
                        <p>Award Winning</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>