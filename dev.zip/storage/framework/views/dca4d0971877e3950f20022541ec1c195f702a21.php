<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">

    <!-- Title Page-->
    <title>Edit Question #<?php echo e($questionDetails->num); ?></title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('manage/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('manage/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.css">
    <!-- Vendor CSS-->
    <link href="<?php echo e(asset('manage/vendor/animsition/animsition.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/wow/animate.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/css-hamburgers/hamburgers.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/slick/slick.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/select2/select2.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/perfect-scrollbar/perfect-scrollbar.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('manage/vendor/vector-map/jqvmap.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="<?php echo e(asset('manage/css/theme.css')); ?>" rel="stylesheet" media="all">

    <style>
        #wrapper{ text-align:center; margin:0px auto; }

        #output_image{ width:280px; height:150px;}
    </style>

    <script type='text/javascript'>
    function preview_image(event) 
    {
     var reader = new FileReader();
     reader.onload = function()
     {
      var output = document.getElementById('output_image');
      output.src = reader.result;
     }
     reader.readAsDataURL(event.target.files[0]);
    }
    </script>

</head>

<body >
    <div class="page-wrapper">
        <?php echo $__env->make('multiauth::_includes.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <?php echo $__env->make('multiauth::_includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- PAGE CONTAINER-->
    <div>
        <!-- MAIN CONTENT-->
        <div class="main-content">
            <div class="section__content section__content--p30">
                <div class="container-fluid">
                     <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">questions</div>
                                <div class="card-body">
                                    <div class="card-title">
                                        <h3 class="text-center title-2">Edit Question #<?php echo e($questionDetails->num); ?></h3>
                                    </div>
                                    <hr>
                                    <form action="<?php echo e(route('admin.questions.update',$questionDetails->id)); ?>" method="post" novalidate="novalidate" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group">
                                            <label class="control-label mb-1">Question in <?php echo e($value['native']); ?></label>
                                            <textarea class="form-control" name="head[<?php echo e($key); ?>]" placeholder="<?php echo e($value['native']); ?>" value="<?php echo e(Unserialize($questionDetails->head)[LaravelLocalization::setLocale($key)]); ?>"><?php echo e(Unserialize($questionDetails->head)[LaravelLocalization::setLocale($key)]); ?></textarea>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <div class="form-group">
                                      
                                          <div class="field_wrapper">
                                            <?php $__currentLoopData = $questionDetails['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <div>
                                                  <input value="<?php echo e($ans->id); ?>" type="hidden" name="idAns[]" id="char" placeholder="char" style="width: 90px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;" class="form-control" required/>

                                                  <input value="<?php echo e($ans->char); ?>" type="text" name="char[]" id="char" placeholder="char" style="width: 90px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;" class="form-control" required/>

                                                  <input value="<?php echo e($ans->answer_en); ?>" type="text" name="answer_en[]" id="answer_en" placeholder="answer in english" style="width: 300px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;" class="form-control" required/>

                                                  <input value="<?php echo e($ans->answer_ar); ?>" type="text" name="answer_ar[]" id="answer_ar" placeholder="answer in arabic" style="width: 300px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;" class="form-control" required/>

                                                   <select  name="status[]" class="form-control" style="width: 110px; border-radius: 4px; margin-right: 3px; margin-top: 2px; display: inline-block;">
                                                        <option value="1" <?php if($ans->correct==1){echo 'selected';} ?>>correct</option>
                                                        <option value="0" <?php if($ans->correct==0){echo 'selected';} ?>>not correct</option>
                                                   </select>
                                              </div>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </div>
                                        </div> 
                                        <div>
                                            <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                <span id="payment-button-amount">Change</span>
                                            </button>

                                            <a style="color: #fff;" class="btn btn-lg btn-danger btn-block" href="<?php echo e(route('admin.exams.index')); ?>">
                                                <span id="payment-button-amount">Back</span>
                                            </a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END MAIN CONTENT-->

        <!-- END PAGE CONTAINER-->
    </div>
    <!-- Add Remove fields JQUERY Dynamically -->

            <?php echo $__env->make('multiauth::_includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

     <!-- Jquery JS-->
    <script src="<?php echo e(asset('manage/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo e(asset('manage/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <!-- Vendor JS       -->
    <script src="<?php echo e(asset('manage/vendor/slick/slick.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/animsition/animsition.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/counter-up/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/counter-up/jquery.counterup.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/circle-progress/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/chartjs/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/select2/select2.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.sampledata.js')); ?>"></script>
    <script src="<?php echo e(asset('manage/vendor/vector-map/jquery.vmap.world.js')); ?>"></script>

    <!-- Main JS-->
    <script src="<?php echo e(asset('manage/js/main.js')); ?>"></script>

</body>

</html>
<!-- end document-->