<?php
    $logo = \App\Logo::where('active','active')->orderBy('id','desc')->first();
    $info = \App\Info::where('active','active')->orderBy('id','desc')->first();
    $home_about = \App\HomeAbout::where('active','active')->first();
    $services = \App\Service::where('active','active')->get();
?>

<footer>
 <div class="container">
    <div class="top-footer">
       <div class="row">
          <div class="col-xl-4 col-lg-4">
             <div class="logo-wrapper"><img src="<?php echo e(asset('/manage/img/logos/'.$logo['image'])); ?>" alt=""></div>
             <p><?php echo e(Unserialize($home_about['body'])[LaravelLocalization::getCurrentLocale()]); ?></p>
          </div>
          <div class="offset-xl-1 col-xl-2 col-lg-2">
             <h4><?php echo app('translator')->getFromJson('home.links'); ?></h4>
             <ul class="userful-links">
                <li><a href="#html"><?php echo app('translator')->getFromJson('home.home'); ?></a></li>
                <li><a href="#about"><?php echo app('translator')->getFromJson('home.about_us'); ?></a></li>
                <li><a href="#services"><?php echo app('translator')->getFromJson('home.services'); ?></a></li>
                <li><a href="#news"><?php echo app('translator')->getFromJson('home.latest_news'); ?></a></li>
                <li><a href="#brands"><?php echo app('translator')->getFromJson('home.brands'); ?></a></li>
             </ul>
          </div>
          <div class="col-xl-2 col-lg-2">
             <h4>Services</h4>
             <ul class="userful-links">
              <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="#services"><?php echo e(Unserialize($service['head'])[LaravelLocalization::getCurrentLocale()]); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </ul>
          </div>
          <div class="col-xl-3 col-lg-4">
             <h4><?php echo app('translator')->getFromJson('home.contact_us'); ?></h4>
             <div class="footer-contact">
                <div class="contact-info">
                   <div class="icon-wrapper"><i class="flaticon-placeholder"></i></div>
                   <p><?php echo e(Unserialize($info['address'])[LaravelLocalization::getCurrentLocale()]); ?></p>
                </div>
                <div class="contact-info">
                   <div class="icon-wrapper"><i class="flaticon-call"></i></div>
                   <p><?php echo e($info['phone']); ?></p>
                </div>
                <div class="contact-info">
                   <div class="icon-wrapper"><i class="flaticon-email"></i></div>
                   <p><?php echo e($info['email']); ?></p>
                </div>
             </div>
          </div>
       </div>
    </div>
    <div class="bottom-footer">
       <p class="text-center">© <?php echo app('translator')->getFromJson('home.copyrights'); ?> alamia. <?php echo app('translator')->getFromJson('home.rights'); ?>.</p>
    </div>
 </div>
</footer>