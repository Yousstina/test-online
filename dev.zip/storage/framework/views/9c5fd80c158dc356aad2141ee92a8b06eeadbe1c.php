<!DOCTYPE html>
<?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
<html lang="en">
<?php elseif(LaravelLocalization::getCurrentLocale() == 'ar'): ?>
<html lang="ar" dir="rtl">
<?php endif; ?>
<title><?php echo $__env->yieldContent('title'); ?></title>
<?php echo $__env->make('front-end._includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<!-- LOADER -->
<div id="preloader">
    <span class="spinner"></span>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<!-- END LOADER --> 

<?php echo $__env->make('front-end._includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>


<!-- START FOOTER -->
<?php echo $__env->make('front-end._includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- END FOOTER -->

<a href="#" class="scrollup" style="display: none;"><i class="ion-ios-arrow-up"></i></a> 

<!-- Latest jQuery --> 
<script src="<?php echo e(asset('front/assets/js/jquery-1.12.4.min.js')); ?>"></script> 
<!-- jquery-ui --> 
<script src="<?php echo e(asset('front/assets/js/jquery-ui.js')); ?>"></script>
<!-- popper min js --> 
<script src="<?php echo e(asset('front/assets/js/popper.min.js')); ?>"></script>
<!-- Latest compiled and minified Bootstrap --> 
<script src="<?php echo e(asset('front/assets/bootstrap/js/bootstrap.min.js')); ?>"></script> 
<!-- owl-carousel min js  --> 
<script src="<?php echo e(asset('front/assets/owlcarousel/js/owl.carousel.min.js')); ?>"></script> 
<!-- magnific-popup min js  --> 
<script src="<?php echo e(asset('front/assets/js/magnific-popup.min.js')); ?>"></script> 
<!-- waypoints min js  --> 
<script src="<?php echo e(asset('front/assets/js/waypoints.min.js')); ?>"></script> 
<!-- parallax js  --> 
<script src="<?php echo e(asset('front/assets/js/parallax.js')); ?>"></script> 
<!-- countdown js  --> 
<script src="<?php echo e(asset('front/assets/js/jquery.countdown.min.js')); ?>"></script> 
<!-- jquery.counterup.min js --> 
<script src="<?php echo e(asset('front/assets/js/jquery.counterup.min.js')); ?>"></script>
<!-- imagesloaded js --> 
<script src="<?php echo e(asset('front/assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
<!-- isotope min js --> 
<script src="<?php echo e(asset('front/assets/js/isotope.min.js')); ?>"></script>
<!-- jquery.parallax-scroll js -->
<script src="<?php echo e(asset('front/assets/js/jquery.parallax-scroll.js')); ?>"></script>
<!-- scripts js --> 
<script src="<?php echo e(asset('front/assets/js/scripts.js')); ?>"></script>

</body>

</html>