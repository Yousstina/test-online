<?php $__env->startSection('title'); ?>
    Home | Online Test
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none"><?php echo e(Auth::user()->name); ?></span>
      <span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="<?php echo e(asset('/manage/img/users/'. auth()->user()->image)); ?>" alt="">
        <h4><?php echo e(Auth::user()->email); ?></h4>
      </span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">
        <li class="nav-item">
          <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
          <a class="nav-link" href="<?php echo e(LaravelLocalization::getLocalizedUrl('ar')); ?>"><i class="fa fa-language"></i> AR</a>
          <?php elseif(LaravelLocalization::getCurrentLocale() == 'ar'): ?>
          <style type="text/css">
            .w-100{
              width: 100%!important;
              margin-right: 271px;
            }
          </style>
          <a class="nav-link" href="<?php echo e(LaravelLocalization::getLocalizedUrl('en')); ?>"><i class="fa fa-language"></i> EN</a>
          <?php endif; ?>
        </li>

        <?php
        $all_exams = DB::table('users_exams')->where('user_id',Auth::user()->id)->whereNull('score')->get();
        ?>

        <?php $__currentLoopData = $all_exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $exam = DB::table('exams')->where('id',$ex->exam_id)->first();
        ?>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="<?php echo e(route('exam',$exam->id)); ?>"><?php echo e(Unserialize($exam->name)[LaravelLocalization::setLocale('en')]); ?>

            <?php if($ex->score == null): ?>
            <span style="background-color: green; border-radius: 4px; text-transform: lowercase; color: #fff;">new</span>
            <?php endif; ?>
          </a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Log Out</a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
          </form>
        </li>
      </ul>
    </div>
  </nav>

  <div class="container-fluid p-0">
    <section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="about">
      <div class="w-100">
        <h1 class="mb-0"><?php echo e(Auth::user()->name); ?>

        </h1>
        <div class="subheading mb-5"><?php echo e(Auth::user()->phone); ?>

          <a href="mailto:name@email.com"><?php echo e(Auth::user()->email); ?></a>
        </div>

        <div class="subheading mb-5">your exams 
          <a href="#"><?php echo e(Auth::user()->exams()->count()); ?></a>
          
        </div>
      </div>
    </section>

    <hr class="m-0">


  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end._includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>