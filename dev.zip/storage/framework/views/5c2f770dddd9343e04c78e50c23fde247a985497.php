 

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row">
                
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <h3 class="title-5 m-b-35">All Exam Types</h3>
                    <div class="table-data__tool">
                        
                        <div class="table-data__tool-right">
                            <a href="<?php echo e(route('admin.exams.create')); ?>" class="au-btn au-btn-icon au-btn--green au-btn--small">
                                <i class="zmdi zmdi-plus"></i>add Type
                            </a>

                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-md btn-danger">
                                <i class="fa fa-mail-forward"></i> back
                            </a>
                            
                        </div>
                    </div>
                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>الاسم</th>
                                    <th>Dealine</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr class="tr-shadow">
                                    <td><?php echo e($exam->id); ?></td>
                                    <td><?php echo e(Unserialize($exam->name)[LaravelLocalization::setLocale('en')]); ?></td>
                                    <td><?php echo e(Unserialize($exam->name)[LaravelLocalization::setLocale('ar')]); ?></td>
                                    
                                    <td><?php echo e($exam->deadline); ?></td>
                                    <td>
                                        <?php if($exam->active == 'inactive'): ?>
                                        <a href="<?php echo e(route('admin.exams.changeStatus',$exam->id)); ?>" class="btn btn-md btn-danger">
                                            Inactive
                                        </a>
                                        <?php elseif($exam->active == 'active'): ?>
                                        <a href="<?php echo e(route('admin.exams.changeStatus',$exam->id)); ?>" class="btn btn-md btn-success">
                                            active
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="table-data-feature">
                                            <a href="<?php echo e(route('admin.questions.index',$exam->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="show questions">
                                                <i class="zmdi zmdi-show"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.exams.edit',$exam->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                <i class="zmdi zmdi-edit"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.exams.delete',$exam->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                <i class="zmdi zmdi-delete"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                            <?php echo e($exams->links()); ?>

                        </table>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>