<?php
    $blogs = \App\Blog::where('active','active')->get();
?>

<div class="news-section" id="news">
         <div class="container">
            <span class="title"><?php echo app('translator')->getFromJson('home.latest_news'); ?></span>
            <h2 class="subtitle"><?php echo app('translator')->getFromJson('home.inside_the_news'); ?></h2>
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="col-lg-4 col-md-6">
                      <div class="single-news wow fadeInRight" data-wow-duration="1.5s">
                         <img src="<?php echo e(asset('/manage/img/blogs/'.$blog['image'])); ?>" alt="">
                         <div class="news-txt">
                            <span class="date"><?php echo e(date("d", strtotime($blog->created_at))); ?> <?php echo e(date("M", strtotime($blog->created_at))); ?>  -  BY <?php echo e(Unserialize($blog['author'])[LaravelLocalization::getCurrentLocale()]); ?></span>
                            <a href="<?php echo e(route('singleBlog',$blog->id)); ?>" class="title">
                               <h3><?php echo e(Unserialize($blog['head'])[LaravelLocalization::getCurrentLocale()]); ?></h3>
                            </a>
                            <a class="readmore" href="<?php echo e(route('singleBlog',$blog->id)); ?>">Read More</a>
                         </div>
                      </div>
                   </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
      </div>

<section class="bg_gray">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
               <div class="heading_s1 text-center animation" data-animation="fadeInUp" data-animation-delay="0.01s">
                  <h2><?php echo app('translator')->getFromJson('home.latest_news'); ?></h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
          <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-lg-4 col-md-6">
                 <div class="blog_post box_shadow1 radius_all_10 animation" data-animation="fadeInUp" data-animation-delay="0.02s">
                    <div class="blog_img radius_ltrt_10">
                          <a href="#">
                              <img src="<?php echo e(asset('manage/img/blogs/'.$blog['image'])); ?>" alt="blog_small_img1">
                              <div class="link_blog">
                                <span class="ripple"><i class="fa fa-link"></i></span>
                              </div>
                          </a>
                      </div>
                      <div class="blog_content bg-white">
                          <h6 class="blog_title"><a href="#"><?php echo e(Unserialize($blog['head'])[LaravelLocalization::getCurrentLocale()]); ?></a></h6>
                          <p><?php echo e(Unserialize($blog['body'])[LaravelLocalization::getCurrentLocale()]); ?></p>
                          <a href="#" class="text-capitalize">Read More</a>
                      </div>
                      <div class="blog_footer bg-white radius_lbrb_10">
                          <ul class="list_none blog_meta">
                              <li><a href="#"><i class="ion-calendar"></i><?php echo e(date("d", strtotime($blog->created_at))); ?> <?php echo e(date("M", strtotime($blog->created_at))); ?></a></li>
                          </ul>
                      </div>
                  </div>
           </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
         <div class="col-12">
               <div class="text-center animation" data-animation="fadeInUp" data-animation-delay="0.04s">
                  <div class="medium_divider"></div>
                  <a href="#" class="btn btn-default">View All Blog <i class="ion-ios-arrow-thin-right ml-1"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="bg_default small_pt small_pb">
   <div class="container">
      <div class="row align-items-center">
         <div class="col-md-8">
               <div class="text_white cta_section">
                  <div class="medium_divider d-block d-md-none"></div>
                    <div class="heading_s1 heading_light">
                        <h2>Get The Coaching Training Today!</h2>
                    </div>
                    <p>If you are going to use a passage of embarrassing hidden in the middle of text</p>
                </div>
            </div>
            <div class="col-md-4">
               <div class="text-md-right">
                    <a href="#" class="btn btn-outline-white">Get Started</a>
                </div>
                <div class="medium_divider d-block d-md-none"></div>
            </div>
        </div>
    </div>
</section>