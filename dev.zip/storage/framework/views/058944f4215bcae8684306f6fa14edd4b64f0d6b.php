<?php
    $ours = \App\Our::where('active','active')->get();
?>
<div class="faq-section home-3" id="ours">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <div class="targets">
               <?php $__currentLoopData = $ours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $our): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="box wow fadeInUp col-lg-6" data-wow-duration="1.5s">
                     <div class="icon-wrapper"><i class="flaticon-<?php echo e($our->icon); ?>"></i></div>
                     <div class="box-details">
                        <h4><?php echo e(Unserialize($our['head'])[LaravelLocalization::getCurrentLocale()]); ?></h4>
                        <p><?php echo e(Unserialize($our['body'])[LaravelLocalization::getCurrentLocale()]); ?></p>
                     </div>
                  </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
      </div>
   </div>
</div>