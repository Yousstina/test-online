 

<?php $__env->startSection('content'); ?>
<style type="text/css">
    .bb{
        padding: 6px 19px;
        font-size: 14px;
        line-height: 24px;
        font-weight: bold;
        background: #60a7d4; 
        display: table;
        color: #fff;
        cursor: pointer;
        text-align: center;
        border-radius: 8px;
        border-width: 2px;
         }



    input[type="file"] {
        display: none;
    }

    input[type="file"] {
        display: none;
    }
</style>
<style>
    #wrapper{ text-align:center; margin:0px auto; }

    #output_image{ width:280px; height:150px;}
</style>

<script type='text/javascript'>
    function preview_image(event) 
    {
     var reader = new FileReader();
     reader.onload = function()
     {
      var output = document.getElementById('output_image');
      output.src = reader.result;
     }
     reader.readAsDataURL(event.target.files[0]);
    }
</script>
<?php
    $categories = \App\Category::where('active','active')->orderBy('id','desc')->get();
?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">      
                <div class="col-lg-12">
                    <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="card">
                        <div class="card-header">
                            <strong>Course</strong>
                            <small> edit</small>
                        </div>
                        <div class="card-body card-block">
                            <form action="<?php echo e(route('admin.courses.update',$courseDetails->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="control-label mb-1">Choose Category</label>
                                            <select name="cat_id" class="form-control" required>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>" <?php if($courseDetails->cat_id == $category->id): ?> selected <?php endif; ?> ><?php echo e(Unserialize($category['head'])[LaravelLocalization::getCurrentLocale()]); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label class="control-label mb-1">Head in <?php echo e($value['native']); ?></label>
                                                <input name="head[<?php echo e($key); ?>]" type="text" class="form-control"  placeholder=" <?php echo e($value['native']); ?>" required value="<?php echo e(Unserialize($courseDetails->head)[LaravelLocalization::setLocale($key)]); ?>">
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label class="control-label mb-1">Body in <?php echo e($value['native']); ?></label>
                                                <textarea name="body[<?php echo e($key); ?>]" type="text" class="form-control"  placeholder=" <?php echo e($value['native']); ?>" required value="<?php echo e(Unserialize($courseDetails->body)[LaravelLocalization::setLocale($key)]); ?>"><?php echo e(Unserialize($courseDetails->body)[LaravelLocalization::setLocale($key)]); ?></textarea>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label class="control-label mb-1">Instructor in <?php echo e($value['native']); ?></label>
                                                <input name="instructor[<?php echo e($key); ?>]" type="text" class="form-control"  placeholder=" <?php echo e($value['native']); ?>" required value="<?php echo e(Unserialize($courseDetails->instructor)[LaravelLocalization::setLocale($key)]); ?>">
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label class="control-label mb-1">Location in <?php echo e($value['native']); ?></label>
                                                <input name="location[<?php echo e($key); ?>]" type="text" class="form-control"  placeholder=" <?php echo e($value['native']); ?>" required value="<?php echo e(Unserialize($courseDetails->location)[LaravelLocalization::setLocale($key)]); ?>">
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label class="control-label mb-1">Price</label>
                                            <input name="price" type="number" class="form-control"  placeholder="course price" required value="<?php echo e($courseDetails->price); ?>">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label class="control-label mb-1">Rate</label>
                                            <select name="rate" class="form-control" required>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="form-group">
                                            <label class="control-label mb-1">From</label>
                                            <input name="from" type="date" class="form-control"  placeholder="" required value="<?php echo e($courseDetails->from); ?>">
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="form-group">
                                            <label class="control-label mb-1">To</label>
                                            <input name="to" type="date" class="form-control"  placeholder="" required value="<?php echo e($courseDetails->to); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                   <div class="col-6">
                                        <div class="form-group">
                                            <div id="wrapper">
                                              <label class="bb"> change image
                                                    <input accept="image/*" onchange="preview_image(event)" type="file" name="image" multiple required value="<?php echo e($courseDetails->image); ?>">
                                              </label>
                                            <div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div> 
                                    <div class="col-6">
                                        <img id="output_image" src="<?php echo e(asset('/manage/img/courses/'.$courseDetails->image)); ?>" />
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-8">
                                        <div>
                                            <button type="submit" name="submit" class="btn btn-lg btn-success btn-block">
                                                <i class="fa fa-edit fa-lg"></i>&nbsp;
                                                <span>change</span>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div>
                                            <a href="<?php echo e(route('admin.courses.index')); ?>" type="submit" name="cancel" class="btn btn-lg btn-danger btn-block">
                                                <i class="fa fa-mail-forward fa-lg"></i>&nbsp;
                                                <span>Back</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>