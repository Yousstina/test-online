<?php
    $logo = \App\Logo::where('active','active')->orderBy('id','desc')->first();
    $socials = \App\Social::where('active','active')->get();
    $info = \App\Info::where('active','active')->orderBy('id','desc')->first();
    $categories = \App\Category::with('courses')->where('active','active')->orderBy('id','desc')->get();
?>

<!-- START HEADER -->
<header class="header_wrap dark_skin">
   <div class="top-header light_skin bg-dark">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <ul class="contact_detail list_none text-center text-md-left">
                        <li><a href="#"><i class="ti-mobile"></i><?php echo e($info['phone']); ?></a></li>
                        <li><a href="#"><i class="ti-email"></i><?php echo e($info['email']); ?></a></li>
                        <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
                        <li><a href="<?php echo e(LaravelLocalization::getLocalizedUrl('ar')); ?>"><i class="fa fa-language"></i>Arabic</a></li>
                        <?php else: ?>
                        <li><a href="<?php echo e(LaravelLocalization::getLocalizedUrl('en')); ?>"><i class="fa fa-language"></i>English</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="col-md-6">
                  <div class="d-flex flex-wrap align-items-center justify-content-md-end justify-content-center mt-2 mt-md-0">
                     <ul class="list_none social_icons social_white text-center text-md-right">
                          <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><a href="<?php echo e($social->link); ?>"><i class="fab fa-<?php echo e($social->lowercase); ?>"></i></a></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                      <ul class="list_none header_list border_list ml-1">
                          <li><a href="#" data-toggle="modal" data-target="#Login">Login</a></li>
                          <li><a href="#" class="btn btn-default btn-sm">Apply Now</a></li>
                      </ul>
                  </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <nav class="navbar navbar-expand-lg"> 
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img class="logo_light" src="<?php echo e(asset('manage/img/logos/'.$logo['image'])); ?>" alt="logo" />
                <img class="logo_dark" src="<?php echo e(asset('manage/img/logos/'.$logo['image'])); ?>" alt="logo" />
                <img class="logo_default" src="<?php echo e(asset('manage/img/logos/'.$logo['image'])); ?>" alt="logo" />
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="ion-android-menu"></span> </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
            <ul class="navbar-nav">
                    <li>
                        <a class="nav-link" href="#">Home</a>
                    </li>

                    <li>
                        <a class="nav-link" href="#">About Us</a>
                    </li>

                    <li class="dropdown">
                        <a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">Courses</a>
                        <div class="dropdown-menu">
                            <ul> 
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="dropdown">
                                    <a class="dropdown-item menu-link dropdown-toggler" href="#"><?php echo e(Unserialize($category['head'])[LaravelLocalization::getCurrentLocale()]); ?> (<?php echo e($category->courses->count()); ?>)</a>
                                    <div class="dropdown-menu">
                                        <ul> 
                                            <?php $__currentLoopData = $category->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a class="dropdown-item nav-link nav_item" href="gallery-three-columns.html"><?php echo e(Unserialize($course['head'])[LaravelLocalization::getCurrentLocale()]); ?></a>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a class="nav-link" href="#">Blogs</a>
                    </li>
                    <li>
                        <a class="nav-link" href="#">Gallery</a>
                    </li>
                    <li>
                        <a class="nav-link" href="#">Contact</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>
<!-- END HEADER --> 