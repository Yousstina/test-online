 

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">      
                <div class="col-lg-12">
                    <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="card">
                        <div class="card-header">
                            <strong>Tag</strong>
                            <small> add to</small>
                            <strong> Blog</strong>
                        </div>
                        <div class="card-body card-block">
                            <form action="<?php echo e(route('admin.blogs.storeTag',$blog_id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-8">
                                        <div class="form-group">
                                            <label class="control-label mb-1">Select Tag</label>
                                            <select name="tag_id" class="form-control" required>
                                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tag->id); ?>"><?php echo e(Unserialize($tag->head)[LaravelLocalization::setLocale('en')]); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-8">
                                        <div>
                                            <button type="submit" name="submit" class="btn btn-lg btn-success btn-block">
                                                <i class="fa fa-plus fa-lg"></i>&nbsp;
                                                <span>add</span>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div>
                                            <a href="<?php echo e(route('admin.blogs.index')); ?>" type="submit" name="cancel" class="btn btn-lg btn-danger btn-block">
                                                <i class="fa fa-mail-forward fa-lg"></i>&nbsp;
                                                <span>Back</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <h3 class="title-5 m-b-35">All Tags</h3>
                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>head</th>
                                    <th>العنوان</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog_tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr class="tr-shadow">
                                    <td><?php echo e($blog_tag->id); ?></td>
                                    <?php
                                        $tag = \App\Tag::where('id',$blog_tag->tag_id)->first();
                                    ?>
                                    <td><?php echo e(Unserialize($tag->head)[LaravelLocalization::setLocale('en')]); ?></td>
                                    <td><?php echo e(Unserialize($tag->head)[LaravelLocalization::setLocale('ar')]); ?></td>
                                    <td>
                                        <div class="table-data-feature">
                                            <a href="<?php echo e(route('admin.blogs.deleteTag',$blog_tag->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                <i class="zmdi zmdi-delete"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>