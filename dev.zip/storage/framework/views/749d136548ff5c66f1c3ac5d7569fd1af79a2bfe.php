<?php $__env->startSection('title'); ?>
   Welcome | Online Test
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    #wrapper{ text-align:center; margin:0px auto; }

    #output_image{ width:100px; height:100px; border-radius: 100%;}
</style>

<script type='text/javascript'>
function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}
</script>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="" alt="">
      </span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">
        <?php if(Route::has('login')): ?>
          <?php if(auth()->guard()->check()): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
            </li>
          <?php else: ?>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#login">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#register">Register</a>
            </li>
            <li class="nav-item">
              <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
              <a class="nav-link" href="<?php echo e(LaravelLocalization::getLocalizedUrl('ar')); ?>"><i class="fa fa-language"></i> AR</a>
              <?php elseif(LaravelLocalization::getCurrentLocale() == 'ar'): ?>
              <style type="text/css">
                .w-100{
                  width: 100%!important;
                  margin-right: 271px;
                }
              </style>
              <a class="nav-link" href="<?php echo e(LaravelLocalization::getLocalizedUrl('en')); ?>"><i class="fa fa-language"></i> EN</a>
              <?php endif; ?>
            </li>
          <?php endif; ?>
        <?php endif; ?>
      </ul>
    </div>
  </nav>

  <div class="container-fluid p-0">
    <section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="login">
      <div class="w-100">
        <h2 class="mb-0">Sign Up Now To attend your exams</h2>
        <form action="<?php echo e(route('login')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="subheading mb-5">Email :
            <input type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>" required autofocus placeholder="enter your email">
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          <div class="subheading mb-5">Password :
            <input type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="enter your password" required>
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
            <label class="form-check-label" for="remember">
              remember me
            </label>
            <input  type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
          </div>
          <button type="submit" class="btn btn-success" class="form-control">Login</button>
        </form>
      </div>
    </section>

    <hr class="m-0">

    <section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="register">
      <div class="w-100">
        <div class="row">
           <h2 class="mb-0">Hurry up! Have an account now </h2>
        </div>
        <form action="<?php echo e(route('register')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-md-6">
              <div class="subheading mb-5">Name :
                <input type="name" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('name')); ?>" required autofocus placeholder="enter your name">
                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Email :
                <input type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>" required placeholder="enter an email">
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Password :
                <input type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" required placeholder="enter password">
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Confirm Password :
                <input id="password-confirm" type="password" name="password_confirmation" class="form-control" required placeholder="confirm password">
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Phone :
                <input type="number" name="phone" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('phone')); ?>" required placeholder="Phone Number">
                <?php if($errors->has('phone')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('phone')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Position :
                <select name="position_id" class="form-control">
                  <option value="1">web developer</option>
                </select>
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Upload Your CV :
                <div id="wrapper">
                 <input type="file" name="cv" required>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Upload Your Image :
                <div id="wrapper">
                 <input type="file" accept="image/*" onchange="preview_image(event)" name="image" required>
                 <img id="output_image"/>

                </div>
              </div>
            </div>
            <div class="col-md-12">
              <button type="submit" class="btn btn-success" class="form-control mb-5">Register</button>
            </div>
          </div>
        </form>
      </div>
    </section>

    <hr class="m-0">
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end._includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>