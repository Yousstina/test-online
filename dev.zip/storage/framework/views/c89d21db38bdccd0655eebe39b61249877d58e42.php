<?php
    $brands = \App\Brand::where('active','active')->get();
?>
<div class="cta-section home-2" id="brands">
   <div class="container">
      <div class="cta-container">
         <div class="row align-items-center">
            <div class="col-md-12">
            <div class="partner-carousel owl-carousel owl-theme">
               <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="single-partner-item">
                  <div class="outer">
                     <div class="inner">
                        <a href="<?php echo e($brand->link); ?>"><img src="<?php echo e(asset('/manage/img/brand/'.$brand['image'])); ?>" alt=""></a>
                     </div>
                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
         </div>
      </div>
   </div>
   <div class="cta-overlay"></div>
</div>