<?php $__env->startSection('title'); ?>
    Single Blog | EgyptAgents
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front-end._includes.inner_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <!--    blog lists start   -->
      <div class="blog-lists">
         <div class="container">
            <div class="row">
               <div class="col-xl-7 col-lg-8">
                  <div class="row">
                     <div class="col-lg-12">
                        <?php $__currentLoopData = $tag->blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-blog">
                           <div class="blog-img-wrapper">
                              <img src="<?php echo e(asset('/manage/img/blogs/'.$blog['image'])); ?>" alt="">
                           </div>
                           <div class="blog-txt">
                              <p class="date"><?php echo e(date("d", strtotime($blog->created_at))); ?> <?php echo e(date("M", strtotime($blog->created_at))); ?>  -  BY <?php echo e(Unserialize($blog['author'])[LaravelLocalization::getCurrentLocale()]); ?></p>
                              <h3 class="blog-title"><a href="<?php echo e(route('singleBlog',$blog->id)); ?>"><?php echo e(Unserialize($blog['head'])[LaravelLocalization::getCurrentLocale()]); ?></a></h3>
                              <p class="blog-summary"><?php echo e(Unserialize($blog['body'])[LaravelLocalization::getCurrentLocale()]); ?>.</p>
                              <a href="<?php echo e(route('singleBlog',$blog->id)); ?>" class="readmore">Read More</a>
                           </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                  </div>
               </div>
               <!--    blog sidebar section start   -->
               <div class="col-xl-4 offset-xl-1 col-lg-4">
                  <div class="sidebar">
                     <div class="blog-sidebar-widgets category-widget">
                        <div class="category-lists">
                           <h4>Categories</h4>
                           <ul>
                              <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li class="single-category"><a href="<?php echo e(route('blogByTag',$tag->url)); ?>"><?php echo e(Unserialize($tag['head'])[LaravelLocalization::getCurrentLocale()]); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
               <!--    blog sidebar section end   -->
            </div>
         </div>
      </div>
      <!--    blog lists end   -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end._includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>