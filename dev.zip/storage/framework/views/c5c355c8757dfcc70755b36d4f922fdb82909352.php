 

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">      
                    <div class="col-lg-12">
                        <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="card">
                            <div class="card-header">
                                <strong>Position</strong>
                                <small> add</small>
                            </div>
                            <div class="card-body card-block">
                                <form action="<?php echo e(route('admin.positions.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-6">
                                                <div class="form-group">
                                                    <label class="control-label mb-1">Head in <?php echo e($value['native']); ?></label>
                                                    <input name="head[<?php echo e($key); ?>]" type="text" class="form-control"  placeholder=" <?php echo e($value['native']); ?>" required>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                    <div class="row">
                                        <div class="col-8">
                                            <div>
                                                <button type="submit" name="submit" class="btn btn-lg btn-success btn-block">
                                                    <i class="fa fa-plus fa-lg"></i>&nbsp;
                                                    <span>add</span>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div>
                                                <a href="<?php echo e(route('admin.positions.index')); ?>" type="submit" name="cancel" class="btn btn-lg btn-danger btn-block">
                                                    <i class="fa fa-mail-forward fa-lg"></i>&nbsp;
                                                    <span>Back</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>