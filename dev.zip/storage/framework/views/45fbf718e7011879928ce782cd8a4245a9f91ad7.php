<?php $__env->startSection('title'); ?>
    EgyptAgents | Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--   header area start   -->
      <?php echo $__env->make('front-end._includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--   header area end   -->
      
   
      
      <!--  hero area start  -->
      <?php echo $__env->make('front-end._includes.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--  hero area end  -->
      
      
      <!--   cta section start    -->
      <?php echo $__env->make('front-end._includes.brands', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--   cta section end    -->

      <!--   faq section start    -->
      <?php echo $__env->make('front-end._includes.ours', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--   faq section end    -->

      <!--  about section start  -->
      <?php echo $__env->make('front-end._includes.about', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--  about section end  -->

      
      
      
      <!--  service section start  -->
      <?php echo $__env->make('front-end._includes.services', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--  service section end  -->
      
      
      
      
      
      <!--  testimonial section start  -->
      <?php echo $__env->make('front-end._includes.testimonials', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--  testimonial section end  -->
      
      
      
      <!--   news section start    -->
      <?php echo $__env->make('front-end._includes.blogs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--   news section end    -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end._includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>