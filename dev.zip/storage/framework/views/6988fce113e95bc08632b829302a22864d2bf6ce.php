 

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row">
                <div class="table-data__tool">
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-md btn-danger">
                        <i class="fa fa-mail-forward"></i> back
                    </a>
                </div>
            </div>
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <h3 class="title-5 m-b-35">All Users With Details</h3>
                    <form class="form-header" action="<?php echo e(route('admin.users.search')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="search" value="1">
                        <input id="search" class="au-input au-input--xl" type="text" name="query" placeholder="Search for users..." style="width:100%;"/>
                    </form>


                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>name</th>
                                    <th>email</th>
                                    <th>phone</th>
                                    <th>CV</th>
                                    <th>JOB</th>
                                    <th>Status</th>
                                    <th>Exams</th>
                                    <th>Total Score</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr class="tr-shadow">
                                    <td>
                                        <img style="width: 70px; height: 70px; border-radius: 100%;" src="<?php echo e(asset('/manage/img/users/'.$user->image)); ?>" alt="">
                                    </td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->phone); ?></td>
                                    <td>
                                        <a href="<?php echo e(asset('/manage/img/users/'.$user->cv)); ?>" target="_blank">Show CV</a>
                                    </td>
                                    <td><?php echo e($user->position_id); ?></td>
                                    <td>
                                        <?php if($user->active == 'inactive'): ?>
                                        <a href="<?php echo e(route('admin.users.changeStatus',$user->id)); ?>" class="btn btn-md btn-danger">
                                            disapproved
                                        </a>
                                        <?php elseif($user->active == 'active'): ?>
                                        <a href="<?php echo e(route('admin.users.changeStatus',$user->id)); ?>" class="btn btn-md btn-success">
                                            approved
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.users.assignExams',$user->id)); ?>" class="btn btn-md btn-primary">
                                            assign exams
                                        </a>
                                    </td>
                                    <?php
                                        $total_score = DB::table('users_exams')->where('user_id',$user->id)->sum('score');
                                    ?>
                                    <td><?php echo e($total_score); ?></td>

                                </tr>
                                <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>