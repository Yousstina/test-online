<?php $__env->startSection('title'); ?>
    FETC | Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- START SECTION BANNER -->
<?php echo $__env->make('front-end._includes.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- END SECTION BANNER -->

<!-- START SECTION CATEGORIES -->
<?php echo $__env->make('front-end._includes.categories', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- END SECTION CATEGORIES -->

<!-- START SECTION FEATURE -->

<!-- END SECTION FEATURE -->



<!-- START SECTION ABOUT -->

<!-- END SECTION ABOUT -->
<?php echo $__env->make('front-end._includes.about', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- START SECTION COURSES -->
<?php echo $__env->make('front-end._includes.courses', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- END SECTION COURSES -->

<!-- START SECTION COUNTER -->

<!-- END SECTION COUNTER -->


<!-- START SECTION GALLERY -->
<?php echo $__env->make('front-end._includes.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- END SECTION GALLERY -->



<!-- START SECTION BLOG -->
<?php echo $__env->make('front-end._includes.blogs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- END SECTION BLOG -->



<!-- END SECTION CALL TO ACTION -->

<!-- END SECTION CALL TO ACTION -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end._includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>