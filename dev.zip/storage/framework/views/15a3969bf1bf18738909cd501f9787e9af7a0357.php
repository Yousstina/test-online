<?php $__env->startSection('title'); ?>
    Single Blog | EgyptAgents
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front-end._includes.inner_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--  breadcrumb start  -->
	  <div class="breadcrumb-area blog-breadcrumb-bg" style="background-image: url('<?php echo e(asset('/manage/img/blogs/'.$blog['image'])); ?>')">
	     <div class="container">
	        <div class="row">
	           <div class="col-lg-8">
	              <div class="breadcrumb-txt">
	                 <span><?php echo app('translator')->getFromJson('home.latest_news'); ?></span>
	                 <h1><?php echo e(Unserialize($blog['head'])[LaravelLocalization::getCurrentLocale()]); ?></h1>
	                 <nav aria-label="breadcrumb">
	                    <ol class="breadcrumb">
	                       <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
	                       <li class="breadcrumb-item active" aria-current="page">Blog</li>
	                    </ol>
	                 </nav>
	              </div>
	           </div>
	        </div>
	     </div>
	     <div class="breadcrumb-overlay"></div>
	  </div>
	  <!--  breadcrumb end  -->
	  <!--    blog details section start   -->
      <div class="blog-details-section section-padding">
         <div class="container">
            <div class="row">
               <div class="col-xl-7 col-lg-8">
                  <div class="blog-details">
                     <img class="blog-details-img-1" src="<?php echo e(asset('/manage/img/blogs/'.$blog['image'])); ?>" alt="">
                     <small class="date"><?php echo e(date("d", strtotime($blog->created_at))); ?> <?php echo e(date("M", strtotime($blog->created_at))); ?>  -  BY <?php echo e(Unserialize($blog['author'])[LaravelLocalization::getCurrentLocale()]); ?></small>
                     <h2 class="blog-details-title"><?php echo e(Unserialize($blog['head'])[LaravelLocalization::getCurrentLocale()]); ?></h2>
                     <div class="blog-details-body">
                        <div class="blog-details-quote"><?php echo e(Unserialize($blog['body'])[LaravelLocalization::getCurrentLocale()]); ?></div>
                     </div>
                  </div>
               </div>
               <!--    blog sidebar section start   -->
               <div class="col-xl-4 offset-xl-1 col-lg-4">
                  <div class="sidebar">

                     <div class="blog-sidebar-widgets">
                        <div class="category-lists">
                           <h4>Categories</h4>
                           <ul>
                           	<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li class="single-category"><a href="<?php echo e(route('blogByTag',$tag->url)); ?>"><?php echo e(Unserialize($tag['head'])[LaravelLocalization::getCurrentLocale()]); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
               <!--    blog sidebar section end   -->
            </div>
         </div>
      </div>
      <!--    blog details section end   -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end._includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>