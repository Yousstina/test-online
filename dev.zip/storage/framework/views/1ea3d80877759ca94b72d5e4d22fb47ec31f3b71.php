<html lang="<?php echo e(LaravelLocalization::getCurrentLocale()); ?>">

<head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style type="text/css">
        @import  url(https://fonts.googleapis.com/earlyaccess/droidarabickufi.css);
        @import  url(https://fonts.googleapis.com/earlyaccess/droidarabicnaskh.css);
      </style>
      <!-- favicon -->
      <link rel="shortcut icon" href="<?php echo e(asset('front/assets/img/favicon.png')); ?>" type="image/x-icon">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/bootstrap.min.css')); ?>">
      <!-- fontawesome css -->
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/flaticon.css')); ?>">
      <!-- fontawesome css -->
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/fontawesome.min.css')); ?>">
      <!-- owl carousel css -->
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/owl.carousel.min.css')); ?>">
      <!-- owl carousel theme css -->
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/owl.theme.default.min.css')); ?>">
      <!-- slicknav css -->
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/slicknav.css')); ?>">
      <!-- animate css -->
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/animate.min.css')); ?>">
      <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
      <!-- main en css -->
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/style.css')); ?>">
      <?php else: ?>
      <!-- main ar css -->
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/style.css')); ?>">
      <?php endif; ?>
      <!-- responsive css -->
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/responsive.css')); ?>">
      <!-- jquery js -->
      <script src="<?php echo e(asset('front/assets/js/jquery-3.3.1.min.js')); ?>"></script>
</head>