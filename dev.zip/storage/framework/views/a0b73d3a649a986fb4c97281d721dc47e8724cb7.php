
<!-- MENU SIDEBAR-->
<aside class="menu-sidebar2">
    <div class="logo">
        <a href="<?php echo e(route('admin.home')); ?>">
            <img src="<?php echo e(asset('manage/images/icon/logo-white.png')); ?>" alt="kayan" />
        </a>
    </div>
    <div class="menu-sidebar2__content js-scrollbar1">
        <nav class="navbar-sidebar2">
            <ul class="list-unstyled navbar__list">
                <li class="active">
                    <a href="<?php echo e(route('admin.home')); ?>">
                        <i class="fas fa-tachometer-alt"></i>Home
                    </a>                
                </li>

                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-picture-o"></i>Sliders
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.sliders.index')); ?>">
                                <i class="fas fa-th-list"></i>show sliders</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.sliders.create')); ?>">
                                <i class="fas fa-plus"></i>add slider</a>
                        </li>
                    </ul>
                </li>



                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-picture-o"></i>Logos
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.logos.index')); ?>">
                                <i class="fas fa-th-list"></i>show logos</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.logos.create')); ?>">
                                <i class="fas fa-plus"></i>add logo</a>
                        </li>
                    </ul>
                </li>



                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-question"></i>Infos
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.infos.index')); ?>">
                                <i class="fas fa-th-list"></i>show infos</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.infos.create')); ?>">
                                <i class="fas fa-plus"></i>add info</a>
                        </li>
                    </ul>
                </li>


                 <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-picture-o"></i>Brands
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.brands.index')); ?>">
                                <i class="fas fa-th-list"></i>show brands</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.brands.create')); ?>">
                                <i class="fas fa-plus"></i>add brand</a>
                        </li>
                    </ul>
                </li>

                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-question"></i>Abouts
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.abouts.index')); ?>">
                                <i class="fas fa-th-list"></i>show abouts</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.abouts.create')); ?>">
                                <i class="fas fa-plus"></i>add about</a>
                        </li>
                    </ul>
                </li>

                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-question"></i>Ours
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.ours.index')); ?>">
                                <i class="fas fa-th-list"></i>show ours</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.ours.create')); ?>">
                                <i class="fas fa-plus"></i>add our</a>
                        </li>
                    </ul>
                </li>

                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-address-card"></i>Home Abouts
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.home_about.index')); ?>">
                                <i class="fas fa-th-list"></i>show Home Abouts</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.home_about.create')); ?>">
                                <i class="fas fa-plus"></i>add home about</a>
                        </li>
                    </ul>
                </li>


                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-tags"></i>Tags
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.tags.index')); ?>">
                                <i class="fas fa-th-list"></i>show tags</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.tags.create')); ?>">
                                <i class="fas fa-plus"></i>add tag</a>
                        </li>
                    </ul>
                </li>


                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-newspaper"></i>Blogs
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.blogs.index')); ?>">
                                <i class="fas fa-th-list"></i>show blogs</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.blogs.create')); ?>">
                                <i class="fas fa-plus"></i>add blog</a>
                        </li>
                    </ul>
                </li>



                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-star"></i>Services
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.services.index')); ?>">
                                <i class="fas fa-th-list"></i>show services</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.services.create')); ?>">
                                <i class="fas fa-plus"></i>add service</a>
                        </li>
                    </ul>
                </li>


                <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas  fa-comments"></i>Testimonials
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.testimonials.index')); ?>">
                                <i class="fas fa-th-list"></i>show testimonials</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.testimonials.create')); ?>">
                                <i class="fas fa-plus"></i>add testimonial</a>
                        </li>
                    </ul>
                </li>



                <li class="has-sub">
                    <a class="js-arrow" href="<?php echo e(route('admin.socials.index')); ?>">
                        <i class="fas  fa-share-square"></i>Socials
                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li>
                            <a href="<?php echo e(route('admin.socials.index')); ?>">
                                <i class="fas fa-th-list"></i>show socials</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.socials.create')); ?>">
                                <i class="fas fa-plus"></i>add social</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<!-- END MENU SIDEBAR-->