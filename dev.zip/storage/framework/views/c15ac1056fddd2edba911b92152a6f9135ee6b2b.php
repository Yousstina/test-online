<?php
    $testimonials = \App\Testimonial::where('active','active')->get();
?>


<div class="testimonial-section home-3" id="testimonials">
         <div class="container">
            <div class="row">
               <div class="col-lg-6">
                  <span class="title"><?php echo app('translator')->getFromJson('home.testimonials'); ?></span>
                  <h2 class="subtitle"><?php echo app('translator')->getFromJson('home.what_they_say'); ?></h2>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class="testimonial-carousel-3 owl-carousel owl-theme">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="single-testimonial">
                        <div class="img-wrapper"><img src="<?php echo e(asset('/manage/img/testimonials/'.$testimonial['image'])); ?>" alt=""></div>
                        <div class="client-desc">
                           <p class="icon-wrapper"><i class="flaticon-quote-left"></i></p>
                           <p class="comment"><?php echo e(Unserialize($testimonial['body'])[LaravelLocalization::getCurrentLocale()]); ?>.</p>
                           <h5 class="name"><?php echo e(Unserialize($testimonial['user_name'])[LaravelLocalization::getCurrentLocale()]); ?></h5>
                           <p class="rank"><?php echo e(Unserialize($testimonial['job_title'])[LaravelLocalization::getCurrentLocale()]); ?></p>
                        </div>
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
               </div>
            </div>
         </div>
      </div>

