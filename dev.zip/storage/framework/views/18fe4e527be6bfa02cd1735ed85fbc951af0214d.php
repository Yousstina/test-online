<section>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright">
                    <p>Copyright © 2019. All rights reserved. by <a href="#">nabolsy</a>.</p>
                </div>
            </div>
        </div>
    </div>
</section>