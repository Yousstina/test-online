<?php
    $categories = \App\Category::where('active','active')->orderBy('id','desc')->get();
    //dd($categories);
    $bg = \App\BackgroundColor::inRandomOrder()->first();
?>

<section class="small_pb">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-8">
                <div class="text-center animation" data-animation="fadeInUp" data-animation-delay="0.01s">
                    <div class="heading_s1 text-center">
                        <h2>Most Popular Categories</h2>
                    </div>
                    <p>If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text</p>
                    <div class="small_divider"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 animation" data-animation="fadeInUp" data-animation-delay="0.02s">
                <div class="course_categories carousel_slider owl-carousel owl-theme nav_style1" data-margin="15" data-loop="true" data-nav="true" data-dots="false" data-autoplay="true" data-responsive='{"0":{"items": "1"}, "380":{"items": "2"}, "576":{"items": "3"}, "1000":{"items": "5"}, "1199":{"items": "6"}}'>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $bg = \App\BackgroundColor::inRandomOrder()->first();
                    ?>
                    <div class="item">
                        <div class="single_categories">
                            <a href="#" class="<?php echo e($bg->color); ?>">
                                <i class="fa fa-<?php echo e($category->icon); ?>"></i>
                                <?php echo e(Unserialize($category['head'])[LaravelLocalization::getCurrentLocale()]); ?>

                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>