
<?php
    $slider = \App\Slider::where('active','active')->orderBy('id','desc')->first();
?>

<div class="hero-area hero-bg-3 home-3" id="hero-home-9">
   <div id="bgndVideo9" data-property="{videoURL:'<?php echo e($slider['video_link']); ?>',containment:'#hero-home-9', quality:'large', autoPlay:true, loop:true, mute:true, opacity:1}"></div>
   <div class="container">
      <div class="row">
         <div class="col-xl-6 col-lg-8">
            <div class="hero-txt">
               <span class="wow fadeInDown" data-wow-duration="1.5s"><?php echo e(Unserialize($slider['head'])[LaravelLocalization::getCurrentLocale()]); ?></span>
               <h1 class="wow fadeInUp" data-wow-duration="1.5s"><?php echo e(Unserialize($slider['body'])[LaravelLocalization::getCurrentLocale()]); ?></h1>
            </div>
         </div>
      </div>
   </div>
   <div class="hero-overlay"></div>
</div>