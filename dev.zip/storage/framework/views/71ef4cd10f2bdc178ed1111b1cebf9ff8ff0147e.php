<?php
    $home_about = \App\HomeAbout::where('active','active')->first();
    $abouts = \App\About::where('active','active')->get();
?>

<div class="about-section home-3" id="about">
         <div class="container">
            <div class="row">
               <div class="col-lg-5">
                  <div class="outer">
                     <div class="inner">
                        <div class="about-txt about-bg-3">
                           <span class="title"><?php echo app('translator')->getFromJson('home.about_us'); ?></span>
                           <h2 class="subtitle"><?php echo e(Unserialize($home_about['head'])[LaravelLocalization::getCurrentLocale()]); ?></h2>
                           <p><?php echo e(Unserialize($home_about['body'])[LaravelLocalization::getCurrentLocale()]); ?></p>
                           <img src="assets/img/signature.png" alt="">
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 offset-lg-1 col-lg-6">
                  <div class="about-points">
                    <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="single-point">
                        <div class="icon-wrapper"><i class="flaticon-<?php echo e($about->icon); ?>"></i></div>
                        <div class="point-txt">
                           <h4><?php echo e(Unserialize($about['head'])[LaravelLocalization::getCurrentLocale()]); ?></h4>
                           <p><?php echo e(Unserialize($about['body'])[LaravelLocalization::getCurrentLocale()]); ?></p>
                        </div>
                     </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
               </div>
            </div>
         </div>
      </div>