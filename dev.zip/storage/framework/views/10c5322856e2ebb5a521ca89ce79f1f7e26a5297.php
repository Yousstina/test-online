 

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <?php echo $__env->make('multiauth::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row">
                
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <h3 class="title-5 m-b-35">All Users With Details</h3>
                    <div class="table-data__tool">
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-md btn-danger">
                                <i class="fa fa-mail-forward"></i> back
                            </a>
                            
                        </div>
                    </div>
                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th>CODE</th>
                                    <th>name</th>
                                    <th>email</th>
                                    <th>Payment Status</th>
                                    <th>Exam Status</th>
                                    <th>Score</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr class="tr-shadow">
                                    <td><?php echo e($user->code); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->phone); ?></td>
                                    <?php
                                        $payment = \App\Payment::where('user_id',$user->id)->first();
                                        $max_exam_id = \App\Exam::where('user_id',$user->id)->max('id');
                                        $exam = \App\Exam::where('id',$max_exam_id)->first();
                                    ?>
                                    <td>
                                        <?php if($payment): ?>
                                            <?php if($payment->paid == 0): ?>
                                            <a href="<?php echo e(route('admin.payments.showDetails',$payment->id)); ?>" class="btn btn-md btn-warning" style="color: #fff;">Waiting for approve</a>
                                            <?php elseif($payment->paid == 1): ?>
                                            <button class="btn btn-md btn-success">Paid</button>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <button class="btn btn-md btn-danger">Unpaid</button>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($exam): ?>
                                            <?php if($exam->open == 1 && $exam->finished == 0): ?>
                                            <button class="btn btn-md btn-warning" style="color: #fff;">Examing</button>
                                            <?php elseif($exam->open == 0 && $exam->finished == 1): ?>
                                            <button class="btn btn-md btn-success">Finished</button>
                                            <a href="<?php echo e(route('admin.users.reOpen',$user->id)); ?>" class="btn btn-md btn-info">Re Open</a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <button class="btn btn-md btn-danger">Not Examed</button>
                                        <?php endif; ?>
                                    </td>
                                    <?php if($exam): ?>
                                    <td><?php echo e($exam->score); ?></td>
                                    <?php else: ?>
                                    <td>no score yet</td>
                                    <?php endif; ?>
                                </tr>
                                <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('multiauth::layouts.manage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>