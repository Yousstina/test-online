<?php

    Route::GET('/home', 'AdminController@index')->name('admin.home');
    // Login and Logout
    Route::GET('/', 'LoginController@showLoginForm')->name('admin.login');
    Route::POST('/', 'LoginController@login');
    Route::POST('/logout', 'LoginController@logout')->name('admin.logout');

    // Password Resets
    Route::POST('/password/email', 'ForgotPasswordController@sendResetLinkEmail')->name('admin.password.email');
    Route::GET('/password/reset', 'ForgotPasswordController@showLinkRequestForm')->name('admin.password.request');
    Route::POST('/password/reset', 'ResetPasswordController@reset');
    Route::GET('/password/reset/{token}', 'ResetPasswordController@showResetForm')->name('admin.password.reset');
    Route::GET('/password/change', 'AdminController@showChangePasswordForm')->name('admin.password.change');
    Route::POST('/password/change', 'AdminController@changePassword');

    // Register Admins
    Route::get('/register', 'RegisterController@showRegistrationForm')->name('admin.register');
    Route::post('/register', 'RegisterController@register');
    Route::get('/{admin}/edit', 'RegisterController@edit')->name('admin.edit');
    Route::delete('/{admin}', 'RegisterController@destroy')->name('admin.delete');
    Route::patch('/{admin}', 'RegisterController@update')->name('admin.update');

    // Admin Lists
    Route::get('/show', 'AdminController@show')->name('admin.show');

    // Admin Roles
    Route::post('/{admin}/role/{role}', 'AdminRoleController@attach')->name('admin.attach.roles');
    Route::delete('/{admin}/role/{role}', 'AdminRoleController@detach');

    // Roles
    Route::get('/roles', 'RoleController@index')->name('admin.roles');
    Route::get('/role/create', 'RoleController@create')->name('admin.role.create');
    Route::post('/role/store', 'RoleController@store')->name('admin.role.store');
    Route::delete('/role/{role}', 'RoleController@destroy')->name('admin.role.delete');
    Route::get('/role/{role}/edit', 'RoleController@edit')->name('admin.role.edit');
    Route::patch('/role/{role}', 'RoleController@update')->name('admin.role.update');

    Route::fallback(function () {
        return abort(404);
    });


    Route::prefix('manage')->group(function() {
        Route::prefix('exams')->group(function() {
            Route::get('/index', 'ExamController@index')->name('admin.exams.index');
            Route::get('/create', 'ExamController@create')->name('admin.exams.create');
            Route::post('/store', 'ExamController@store')->name('admin.exams.store');
            Route::get('/edit/{id}', 'ExamController@edit')->name('admin.exams.edit');
            Route::post('/update/{id}', 'ExamController@update')->name('admin.exams.update');
            Route::get('/delete/{id}', 'ExamController@delete')->name('admin.exams.delete');
            Route::get('/change-status/{id}', 'ExamController@changeStatus')->name('admin.exams.changeStatus');
        });

        Route::prefix('questions')->group(function() {
            Route::get('/index/{exam_id}', 'QuestionController@index')->name('admin.questions.index');
            Route::get('/create/{exam_id}', 'QuestionController@create')->name('admin.questions.create');
            Route::post('/store/{exam_id}', 'QuestionController@store')->name('admin.questions.store');
            Route::get('/edit/{id}', 'QuestionController@edit')->name('admin.questions.edit');
            Route::post('/update/{id}', 'QuestionController@update')->name('admin.questions.update');
            Route::get('/delete/{id}', 'QuestionController@delete')->name('admin.questions.delete');
            Route::get('/change-status/{id}', 'QuestionController@changeStatus')->name('admin.questions.changeStatus');
        });

        Route::prefix('positions')->group(function() {
            Route::get('/index', 'PositionController@index')->name('admin.positions.index');
            Route::get('/create', 'PositionController@create')->name('admin.positions.create');
            Route::post('/store', 'PositionController@store')->name('admin.positions.store');
            Route::get('/edit/{id}', 'PositionController@edit')->name('admin.positions.edit');
            Route::post('/update/{id}', 'PositionController@update')->name('admin.positions.update');
            Route::get('/delete/{id}', 'PositionController@delete')->name('admin.positions.delete');
            Route::get('/change-status/{id}', 'PositionController@changeStatus')->name('admin.positions.changeStatus');
        });

        Route::prefix('users')->group(function() {
            Route::get('/index', 'UserController@index')->name('admin.users.index');
            Route::post('/search', 'UserController@index')->name('admin.users.search');
            Route::get('/assign-exams/{user_id}', 'UserExamController@assignExams')->name('admin.users.assignExams');
            Route::post('/assign/{user_id}', 'UserExamController@assign')->name('admin.users.assign');
            Route::get('/delete-exam/{id}', 'UserExamController@delete')->name('admin.users.deleteExam');

            Route::get('/change-status/{id}', 'UserController@changeStatus')->name('admin.users.changeStatus');
        });

    });
