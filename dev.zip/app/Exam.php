<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exam extends Model
{
    public function users()
    {
        return $this->belongsToMany('App\User','users_exams', 'exam_id','user_id');
    }

    public function questions()
    {
    	return $this->hasMany('App\Question', 'exam_id');
    }
}
