<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Position;
class WelcomeController extends Controller
{
    public function welcome()
    {
    	$positions = Position::where('active','active')->get();
    	return view('welcome')->with(compact('positions'));
    }
}
