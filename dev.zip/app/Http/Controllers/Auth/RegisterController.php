<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255','unique:users'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            'phone' => ['required', 'string', 'min:11', 'max:11' ,'unique:users'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        //dd($data);
        $user = new User();
        $user->name = $data['name'];
        $user->email = $data['email'];
        $user->phone = $data['phone'];
        $user->position_id = $data['position_id'];
        $user->password = Hash::make($data['password']);
        $user->save();

        if ($data['image']) {
            $this->uploadImage($data['image'], $user->id);
        }

        if ($data['cv']) {
            $this->uploadCV($data['cv'], $user->id);
        }

        return $user;
    }

    public function uploadImage($image, $user_id)
    {

        $input['image'] = time().'.'.$image->getClientOriginalExtension();
        $dist = public_path('/manage/img/users/');
        
        $image->move($dist, $input['image']);
        
        $im = User::findOrFail($user_id);
        $im->image = $input['image'];
        $im->save();
    }

    public function uploadCV($cv, $user_id)
    {

        $input['cv'] = time().'.'.$cv->getClientOriginalExtension();
        $dist = public_path('/manage/img/users/');
        
        $cv->move($dist, $input['cv']);
        
        $im = User::findOrFail($user_id);
        $im->cv = $input['cv'];
        $im->save();
    }
}
