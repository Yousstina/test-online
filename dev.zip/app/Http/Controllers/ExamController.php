<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Exam;
use App\Question;
use App\Answer;
use DB;
class ExamController extends Controller
{
    public function exam($id)
    {
    	$exam = Exam::where('id',$id)->first();
    	//$exam = json_decode(json_encode($exam));
    	//echo "<pre>"; print_r($exam); die;

    	$questions = Question::where('exam_id',$id)->with('answers')->inRandomOrder()->get()->take(5);
    	//$questions = json_decode(json_encode($questions));
    	//echo "<pre>"; print_r($questions); die;
    	return view('front-end.public_templates.exam')->with(compact('exam','questions'));
    }

    public function submitAnswers(Request $request)
    {
        $user_exam = DB::table('users_exams')->where('user_id',$request->user_id)->where('exam_id',$request->exam_id)->first();
        if ($user_exam->score != null) {
            return redirect('/home')->with('message','Sorry you passed this exam before!');
        }
        $questions  = Question::get();
        $data = $request->all();
        $total = 0;
        $list= [];
        //$data = json_decode(json_encode($data));
        //echo "<pre>"; print_r($data); die;
        if ($request->answers) {
            foreach ($data['answers'] as $key => $q) {
               //dd($q);
                $nmn  = Question::where('id',$key)->first();
                $list[$key]['ans_id'] = $q;
            }

             //dd($list);
            foreach ($list as $key =>$value) {
                //dd($value['ans_id']);
                if ($key) {
                    $ans =  $value['ans_id'];
                    $ansData = Answer::find($ans);
                    if ($ansData->correct == 1) {
                        $total += 1;
                    }else{

                    }
                }else{

                }
            }
        }
        //dd($exam->id);
        DB::table('users_exams')
        	->where('user_id',$request->user_id)
        	->where('exam_id',$request->exam_id)
            ->update(['score' => $total]);
        $questions = Question::where('exam_id',$request->exam_id)->get();
        $exam = Exam::where('id',$request->exam_id)->first();
        //echo $total;
        return view('front-end.public_templates.thanks')->with(compact('total','questions','exam'));
    }

}
