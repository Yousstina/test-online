<?php

return [


    'language' => 'اللغة',
    'brands' => 'العلامات التجارية',
    'our_mission' => 'مهمتنا',
    'about_us' => 'معلومات عنا',
    'services' => 'خدمات',
    'home' => 'الصفحة الرئيسية',
    'latest_news' => 'أحدث الأخبار',
    'testimonials' => 'التوصيات',
    'our_services' => 'خدماتنا',
    'what_we_provide' => 'ما نقدمه',
    'what_they_say' => 'ماذا يقولون',
    'inside_the_news' => 'داخل الأخبار',
    'links' => 'روابط مفيدة',
    'contact_us' => 'اتصل بنا',
    'copyrights' => 'حقوق التأليف والنشر 2019',
    'rights' => 'كل الحقوق محفوظة',

];