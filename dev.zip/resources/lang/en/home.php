<?php

return [


    'language' => 'Language',
    'brands' => 'brands',
    'our_mission' => 'our mission',
    'about_us' => 'about us',
    'services' => 'services',
    'home' => 'home',
    'latest_news' => 'latest news',
    'testimonials' => 'testimonials',
    'our' => 'our',
    'what_we_provide' => 'WHAT WE PROVIDE',
    'what_they_say' => 'WHAT THEY SAY',
    'inside_the_news' => 'INSIDE THE NEWS',
    'links' => 'USEFUL LINKS',
    'contact_us' => 'CONTACT US',
    'copyrights' => 'Copyrights 2019',
    'rights' => 'All rights reserved',

];