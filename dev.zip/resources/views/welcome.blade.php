@extends('front-end._includes.master')

@section('title')
   Welcome | Online Test
@endsection

@section('content')
<style>
    #wrapper{ text-align:center; margin:0px auto; }

    #output_image{ width:100px; height:100px; border-radius: 100%;}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type='text/javascript'>
function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}
</script>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="" alt="">
      </span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">
        @if (Route::has('login'))
          @auth
            <li class="nav-item">
              <a class="nav-link" href="{{ route('home') }}">Home</a>
            </li>
          @else
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#login">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#register">Register</a>
            </li>
            <li class="nav-item">
              @if(LaravelLocalization::getCurrentLocale() == 'en')
              <a class="nav-link" href="{{ LaravelLocalization::getLocalizedUrl('ar') }}"><i class="fa fa-language"></i> AR</a>
              @elseif(LaravelLocalization::getCurrentLocale() == 'ar')
              <style type="text/css">
                .w-100{
                  width: 100%!important;
                  margin-right: 271px;
                }
              </style>
              <a class="nav-link" href="{{ LaravelLocalization::getLocalizedUrl('en') }}"><i class="fa fa-language"></i> EN</a>
              @endif
            </li>
          @endauth
        @endif
      </ul>
    </div>
  </nav>

  <div class="container-fluid p-0">
    <section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="login">
      <div class="w-100">
        <h2 class="mb-0">Sign Up Now To attend your exams</h2>
        <form action="{{ route('login') }}" method="post" >
          @csrf
          <div class="subheading mb-5">Email :
            <input type="email" name="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" value="{{ old('email') }}" required autofocus placeholder="enter your email">
            @if ($errors->has('email'))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('email') }}</strong>
                </span>
            @endif
          </div>

          <div class="subheading mb-5">Password :
            <input type="password" name="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" placeholder="enter your password" required>
            @if ($errors->has('password'))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('password') }}</strong>
                </span>
            @endif
            <label class="form-check-label" for="remember">
              remember me
            </label>
            <input  type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
          </div>
          <button type="submit" class="btn btn-success" class="form-control">Login</button>
        </form>
      </div>
    </section>

    <hr class="m-0">

    <section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="register">
      <div class="w-100">
        <div class="row">
           <h2 class="mb-0">Hurry up! Have an account now </h2>
        </div>
        <form action="{{ route('register') }}" method="post" enctype="multipart/form-data" >
          @csrf
          <div class="row">
            <div class="col-md-6">
              <div class="subheading mb-5">Name :
                <input type="name" name="name" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" value="{{ old('name') }}" required autofocus placeholder="enter your name">
                @if ($errors->has('name'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('name') }}</strong>
                    </span>
                @endif
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Email :
                <input type="email" name="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" value="{{ old('email') }}" required placeholder="enter an email">
                @if ($errors->has('email'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('email') }}</strong>
                    </span>
                @endif
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Password :
                <input type="password" name="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" required placeholder="enter password">
                @if ($errors->has('password'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('password') }}</strong>
                    </span>
                @endif
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Confirm Password :
                <input id="password-confirm" type="password" name="password_confirmation" class="form-control" required placeholder="confirm password">
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Phone :
                <input type="number" name="phone" class="form-control{{ $errors->has('phone') ? ' is-invalid' : '' }}" value="{{ old('phone') }}" required placeholder="Phone Number">
                @if ($errors->has('phone'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('phone') }}</strong>
                    </span>
                @endif
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Position :
                <select name="position_id" class="form-control">
                  @foreach($positions as $position)
                  <option value="{{ $position->id }}">{{ Unserialize($position['head'])[LaravelLocalization::getCurrentLocale()] }}</option>
                  @endforeach
                </select>
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Upload Your CV :
                <div id="wrapper">
                 <input type="file" name="cv" required>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="subheading mb-5">Upload Your Image :
                <div id="wrapper">
                 <input type="file" accept="image/*" onchange="preview_image(event)" name="image" required>
                 <img id="output_image"/>

                </div>
              </div>
            </div>
            <div class="col-md-12">
              <button type="submit" class="btn btn-success" class="form-control mb-5">Register</button>
            </div>
          </div>
        </form>
      </div>
    </section>

    <hr class="m-0">
  </div>
  <script type="text/javascript">

    /*$('#register-form').submit(function(event){
      event.preventDefault()
      var postData = {
        'email': $('input[name=email]').val(),
        'password':$('input[name=password]').val(),
      }

      $.ajax({
        type:'POST',
        url:'/register',
        data:postData,
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success:function(response){

        },
        error:function(response){
          console.log(response);
        }
      })
    })*/
  </script>
@endsection