@extends('front-end._includes.master')

@section('title')
    Home | Online Test
@endsection

@section('content')
<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">{{ Auth::user()->name }}</span>
      <span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="{{ asset('/manage/img/users/'. auth()->user()->image) }}" alt="">
        <h4>{{ Auth::user()->email }}</h4>
      </span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">
        <li class="nav-item">
          @if(LaravelLocalization::getCurrentLocale() == 'en')
          <a class="nav-link" href="{{ LaravelLocalization::getLocalizedUrl('ar') }}"><i class="fa fa-language"></i> AR</a>
          @elseif(LaravelLocalization::getCurrentLocale() == 'ar')
          <style type="text/css">
            .w-100{
              width: 100%!important;
              margin-right: 271px;
            }
          </style>
          <a class="nav-link" href="{{ LaravelLocalization::getLocalizedUrl('en') }}"><i class="fa fa-language"></i> EN</a>
          @endif
        </li>

        @php
        $all_exams = DB::table('users_exams')->where('user_id',Auth::user()->id)->whereNull('score')->get();
        @endphp

        @foreach($all_exams as $ex)
        @php
        $exam = DB::table('exams')->where('id',$ex->exam_id)->first();
        @endphp
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="{{ route('exam',$exam->id) }}">{{ Unserialize($exam->name)[LaravelLocalization::setLocale('en')] }}
            @if($ex->score == null)
            <span style="background-color: green; border-radius: 4px; text-transform: lowercase; color: #fff;">new</span>
            @endif
          </a>
        </li>
        @endforeach
        <li class="nav-item">
          <a class="nav-link" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Log Out</a>
          <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
              @csrf
          </form>
        </li>
      </ul>
    </div>
  </nav>

  <div class="container-fluid p-0">
    <section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="about">
      <div class="w-100">
        <h1 class="mb-0">{{ Auth::user()->name }}
        </h1>
        <div class="subheading mb-5">{{ Auth::user()->phone }}
          <a href="mailto:name@email.com">{{ Auth::user()->email }}</a>
        </div>

        <div class="subheading mb-5">your exams 
          <a href="#">{{ Auth::user()->exams()->count() }}</a>
          
        </div>
      </div>
    </section>

    <hr class="m-0">


  </div>
@endsection